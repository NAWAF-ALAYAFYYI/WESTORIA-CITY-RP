import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { trpc } from "@/lib/trpc";
import {
  LayoutDashboard,
  ArrowUpCircle,
  Shield,
  Briefcase,
  Landmark,
  Users,
  FileText,
  ScrollText,
  KeyRound,
  Settings,
  LogOut,
  Menu,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { startLogin } from "@/const";

interface NavItem {
  href: string;
  label: string;
  icon: typeof LayoutDashboard;
  staffOnly?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { href: "/", label: "نظرة عامة", icon: LayoutDashboard, staffOnly: true },
  { href: "/promotions", label: "إدارة الترقيات", icon: ArrowUpCircle },
  { href: "/departments/military", label: "الأقسام العسكرية", icon: Shield, staffOnly: true },
  { href: "/departments/civilian", label: "الوظائف المدنية", icon: Briefcase, staffOnly: true },
  { href: "/departments/government", label: "القطاعات الحكومية", icon: Landmark, staffOnly: true },
  { href: "/citizens", label: "سجلات المواطنين", icon: Users, staffOnly: true },
  { href: "/applications", label: "الطلبات", icon: FileText, staffOnly: true },
  { href: "/audit", label: "سجلات النشاط", icon: ScrollText, staffOnly: true },
  { href: "/roles", label: "الأدوار والصلاحيات", icon: KeyRound, staffOnly: true },
  { href: "/settings", label: "إعدادات النظام", icon: Settings, staffOnly: true },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { data: user } = trpc.auth.me.useQuery();

  const isStaff = user?.role === "staff" || user?.role === "admin";
  const items = NAV_ITEMS.filter(item => !item.staffOnly || isStaff);

  const utils = trpc.useUtils();
  const logout = trpc.auth.logout.useMutation({
    onSuccess: () => {
      utils.auth.me.setData(undefined, undefined);
      window.location.href = "/login";
    },
  });

  const sidebar = (
    <div className="flex h-full flex-col gap-1 bg-sidebar border-l border-sidebar-border">
      <div className="flex items-center justify-center gap-3 px-4 py-6">
        <img src="/logo.png" alt="شعار ويستوريا" className="h-16 w-16 rounded-full" />
        <div className="text-center">
          <div className="text-lg font-extrabold tracking-wide text-foreground">ويستوريا</div>
          <div className="text-[11px] font-semibold text-muted-foreground">منصة إدارة المدينة</div>
        </div>
      </div>
      <div className="westoria-divider mx-4 mb-2" />
      <nav className="flex-1 space-y-1 px-3 overflow-y-auto">
        {items.map(item => {
          const active = location === item.href;
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)}>
              <span
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold transition-all duration-200",
                  active
                    ? "bg-sidebar-accent text-sidebar-accent-foreground westoria-glow"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"
                )}
              >
                <Icon className={cn("h-4.5 w-4.5", active ? "text-primary" : "")} />
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>
      <div className="westoria-divider mx-4" />
      <div className="flex items-center justify-between px-4 py-4">
        <div className="flex items-center gap-2 min-w-0">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/15 text-sm font-bold text-primary">
            {(user?.name ?? "ز").slice(0, 1)}
          </div>
          <div className="min-w-0">
            <div className="truncate text-sm font-bold">{user?.name ?? "غير مسجل"}</div>
            <div className="text-[11px] text-muted-foreground">
              {user?.role === "admin" ? "مدير النظام" : user?.role === "staff" ? "مشرف" : "لاعب"}
            </div>
          </div>
        </div>
        <Button variant="ghost" size="icon" onClick={() => logout.mutate()} title="تسجيل الخروج">
          <LogOut className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen" dir="rtl">
      {/* Desktop sidebar (right side in RTL) */}
      <aside className="hidden lg:block w-64 shrink-0 fixed inset-y-0 right-0 z-30">{sidebar}</aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-40">
          <div className="absolute inset-0 bg-black/70" onClick={() => setMobileOpen(false)} />
          <aside className="absolute inset-y-0 right-0 w-72">
            <button
              className="absolute top-4 -left-10 rounded-full bg-card p-2 border border-border"
              onClick={() => setMobileOpen(false)}
              aria-label="إغلاق القائمة"
            >
              <X className="h-4 w-4" />
            </button>
            {sidebar}
          </aside>
        </div>
      )}

      <div className="flex-1 flex flex-col lg:mr-64 min-w-0">
        <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobileOpen(true)} aria-label="القائمة">
              <Menu className="h-5 w-5" />
            </Button>
            <span className="text-sm font-bold text-muted-foreground">لوحة قيادة مدينة ويستوريا</span>
          </div>
          {!user && (
            <Button size="sm" onClick={() => startLogin()}>
              تسجيل الدخول
            </Button>
          )}
        </header>
        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
