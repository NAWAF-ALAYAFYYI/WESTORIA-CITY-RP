import { useQuery } from "@tanstack/react-query";
import { trpc } from "@/lib/trpc";
import { Loader2, ShieldAlert } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { startLogin } from "@/const";

/**
 * Route guard: unauthenticated visitors get the login screen; ordinary
 * players are separated from staff/admin-only pages server-side and here.
 */
export function AuthGuard({ children, staffOnly = false }: { children: React.ReactNode; staffOnly?: boolean }) {
  const { data: user, isLoading } = trpc.auth.me.useQuery();

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <img src="/logo.png" alt="ويستوريا" className="h-20 w-20 rounded-full animate-pulse" />
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4" dir="rtl">
        <Card className="westoria-card max-w-md w-full text-center">
          <CardContent className="flex flex-col items-center gap-4 p-8">
            <img src="/logo.png" alt="ويستوريا" className="h-24 w-24 rounded-full" />
            <p className="text-muted-foreground">سجّل الدخول للوصول إلى منصة المدينة</p>
            <button
              onClick={() => startLogin()}
              className="rounded-lg bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground transition hover:opacity-90 westoria-glow"
            >
              تسجيل الدخول
            </button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (staffOnly && user.role === "player") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4" dir="rtl">
        <Card className="westoria-card max-w-md w-full text-center">
          <CardContent className="flex flex-col items-center gap-4 p-8">
            <ShieldAlert className="h-12 w-12 text-destructive" />
            <h2 className="text-lg font-extrabold">لا تملك صلاحية الوصول</h2>
            <p className="text-sm text-muted-foreground">هذه الصفحة متاحة للمشرفين وإدارة النظام فقط.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
}
