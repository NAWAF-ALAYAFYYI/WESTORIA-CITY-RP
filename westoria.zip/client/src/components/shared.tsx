import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

const STATUS_LABELS: Record<string, { label: string; className: string }> = {
  pending: { label: "بانتظار التقييم", className: "bg-amber-500/15 text-amber-300 border-amber-500/30" },
  eligible: { label: "مؤهل", className: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30" },
  ineligible: { label: "غير مؤهل", className: "bg-red-500/15 text-red-300 border-red-500/30" },
  approved: { label: "تمت الموافقة", className: "bg-sky-500/15 text-sky-300 border-sky-500/30" },
  rejected: { label: "مرفوض", className: "bg-red-500/15 text-red-300 border-red-500/30" },
  completed: { label: "منجز", className: "bg-primary/15 text-primary border-primary/30" },
  accepted: { label: "مقبول", className: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30" },
};

export function StatusBadge({ status }: { status: string }) {
  const meta = STATUS_LABELS[status] ?? { label: status, className: "" };
  return (
    <Badge variant="outline" className={cn("border", meta.className)}>
      {meta.label}
    </Badge>
  );
}

export const DEPARTMENT_TYPE_LABELS: Record<string, string> = {
  military: "أقسام عسكرية",
  government: "قطاعات حكومية",
  civilian: "وظائف مدنية",
};

export const ROLE_LABELS: Record<string, string> = {
  player: "لاعب",
  staff: "مشرف",
  admin: "مدير النظام",
};

/** Mandatory confirmation dialog for sensitive actions (bulk approval). */
export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = "تأكيد التنفيذ",
  onConfirm,
  onCancel,
  processing = false,
}: {
  open: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
  processing?: boolean;
}) {
  return (
    <AlertDialog open={open}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="text-lg font-extrabold">{title}</AlertDialogTitle>
          <AlertDialogDescription className="leading-relaxed">{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={onCancel} disabled={processing}>
            إلغاء
          </AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm} disabled={processing}>
            {processing ? "جارٍ التنفيذ..." : confirmLabel}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export function PageHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-6">
      <h1 className="text-2xl font-extrabold tracking-tight">{title}</h1>
      {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
      <div className="westoria-divider mt-4" />
    </div>
  );
}
