import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Login from "@/pages/Login";
import Apply from "@/pages/Apply";
import Dashboard from "@/pages/Dashboard";
import Promotions from "@/pages/Promotions";
import StaffPromotions from "@/pages/StaffPromotions";
import Departments from "@/pages/Departments";
import Citizens from "@/pages/Citizens";
import Applications from "@/pages/Applications";
import Audit from "@/pages/Audit";
import Roles from "@/pages/Roles";
import Settings from "@/pages/Settings";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { AppLayout } from "./components/AppLayout";
import { AuthGuard } from "./components/AuthGuard";
import { ThemeProvider } from "./contexts/ThemeContext";

function StaffPage({ children }: { children: React.ReactNode }) {
  return (
    <AuthGuard staffOnly>
      <AppLayout>{children}</AppLayout>
    </AuthGuard>
  );
}

function PlayerPage({ children }: { children: React.ReactNode }) {
  return (
    <AuthGuard>
      <AppLayout>{children}</AppLayout>
    </AuthGuard>
  );
}

function Router() {
  return (
    <Switch>
      <Route path={"/login"} component={Login} />
      <Route path={"/apply"} component={Apply} />
      <Route path={"/"}>
        <StaffPage>
          <Dashboard />
        </StaffPage>
      </Route>
      <Route path={"/promotions"}>
        <PlayerPage>
          <Promotions />
        </PlayerPage>
      </Route>
      <Route path={"/staff/promotions"}>
        <StaffPage>
          <StaffPromotions />
        </StaffPage>
      </Route>
      <Route path={"/departments/military"}>
        <StaffPage>
          <Departments type="military" />
        </StaffPage>
      </Route>
      <Route path={"/departments/civilian"}>
        <StaffPage>
          <Departments type="civilian" />
        </StaffPage>
      </Route>
      <Route path={"/departments/government"}>
        <StaffPage>
          <Departments type="government" />
        </StaffPage>
      </Route>
      <Route path={"/citizens"}>
        <StaffPage>
          <Citizens />
        </StaffPage>
      </Route>
      <Route path={"/applications"}>
        <StaffPage>
          <Applications />
        </StaffPage>
      </Route>
      <Route path={"/audit"}>
        <StaffPage>
          <Audit />
        </StaffPage>
      </Route>
      <Route path={"/roles"}>
        <StaffPage>
          <Roles />
        </StaffPage>
      </Route>
      <Route path={"/settings"}>
        <StaffPage>
          <Settings />
        </StaffPage>
      </Route>
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster dir="rtl" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
