import { useQuery } from "@tanstack/react-query";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { PageHeader } from "@/components/shared";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ScrollText } from "lucide-react";

export default function Audit() {
  const { data, isLoading } = trpc.audit.list.useQuery();

  return (
    <div>
      <PageHeader title="سجلات النشاط" subtitle="سجل تدقيق غير قابل للتعديل لكل فعل حساس في المنصة" />

      <Card className="westoria-card border">
        <CardContent className="p-0">
          {isLoading ? (
            <p className="p-6 text-sm text-muted-foreground">جارٍ التحميل...</p>
          ) : data?.length ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">الفعل</TableHead>
                    <TableHead className="text-right">المنفّذ</TableHead>
                    <TableHead className="text-right">الكيان</TableHead>
                    <TableHead className="text-right">التفاصيل</TableHead>
                    <TableHead className="text-right">الوقت</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.map(log => (
                    <TableRow key={log.id}>
                      <TableCell className="font-mono text-xs text-primary">{log.action}</TableCell>
                      <TableCell>{log.actorName ?? "نظام"}</TableCell>
                      <TableCell className="text-xs">{log.entityType}{log.entityId ? ` #${log.entityId}` : ""}</TableCell>
                      <TableCell dir="ltr" className="max-w-[280px] truncate font-mono text-[11px] text-muted-foreground">
                        {log.details ? JSON.stringify(log.details) : "—"}
                      </TableCell>
                      <TableCell className="text-xs">{new Date(log.createdAt).toLocaleString("ar")}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2 p-10 text-muted-foreground">
              <ScrollText className="h-8 w-8" />
              <p className="text-sm">لا توجد سجلات بعد</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
