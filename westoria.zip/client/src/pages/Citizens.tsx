import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { PageHeader } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, Search, Users } from "lucide-react";

export default function Citizens() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ discordId: "", characterName: "", notes: "" });

  const { data, isLoading } = trpc.citizens.list.useQuery({ search: search || undefined });

  const upsert = trpc.citizens.upsert.useMutation({
    onSuccess: () => {
      toast.success("حُفظ سجل المواطن");
      setDialogOpen(false);
      setForm({ discordId: "", characterName: "", notes: "" });
      qc.invalidateQueries({ queryKey: [["citizens", "list"]] });
    },
    onError: err => toast.error("تعذر الحفظ", { description: err.message }),
  });
  const saveCitizen = () =>
    upsert.mutate({
        discordId: form.discordId,
        characterName: form.characterName,
        notes: form.notes || null,
    });

  return (
    <div>
      <PageHeader title="سجلات المواطنين" subtitle="شخصيات المجتمع المقيمة في ويستوريا وقسمها ورتبتها الحالية" />

      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="relative w-full max-w-xs">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="ابحث بالاسم أو معرف Discord..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pr-9"
          />
        </div>
        <Button onClick={() => setDialogOpen(true)}>
          <Plus className="h-4 w-4" /> سجل مواطن
        </Button>
      </div>

      <Card className="westoria-card border">
        <CardContent className="p-0">
          {isLoading ? (
            <p className="p-6 text-sm text-muted-foreground">جارٍ التحميل...</p>
          ) : data?.length ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">الشخصية</TableHead>
                  <TableHead className="text-right">معرف Discord</TableHead>
                  <TableHead className="text-right">القسم</TableHead>
                  <TableHead className="text-right">الرتبة الحالية</TableHead>
                  <TableHead className="text-right">تاريخ الانضمام</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.map(({ citizen, departmentName }) => (
                  <TableRow key={citizen.id}>
                    <TableCell className="font-bold">{citizen.characterName}</TableCell>
                    <TableCell dir="ltr" className="font-mono text-xs">{citizen.discordId}</TableCell>
                    <TableCell>{departmentName ?? "—"}</TableCell>
                    <TableCell>{citizen.currentRank ?? "—"}</TableCell>
                    <TableCell>{new Date(citizen.joinedAt).toLocaleDateString("ar")}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center gap-2 p-10 text-muted-foreground">
              <Users className="h-8 w-8" />
              <p className="text-sm">لا توجد سجلات مواطنين بعد</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>سجل مواطن جديد</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>معرف Discord</Label>
              <Input dir="ltr" value={form.discordId} onChange={e => setForm(f => ({ ...f, discordId: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>اسم الشخصية</Label>
              <Input value={form.characterName} onChange={e => setForm(f => ({ ...f, characterName: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>ملاحظات</Label>
              <Textarea rows={3} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={saveCitizen} disabled={upsert.isPending}>حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
