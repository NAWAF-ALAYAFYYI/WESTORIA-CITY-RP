import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { PageHeader, ROLE_LABELS } from "@/components/shared";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { KeyRound } from "lucide-react";

export default function Roles() {
  const qc = useQueryClient();
  const { data: user } = trpc.auth.me.useQuery();
  const { data, isLoading } = trpc.users.list.useQuery();

  const updateRole = trpc.users.updateRole.useMutation({
    onSuccess: () => {
      toast.success("حُدد الدور الجديد وسُجل في سجلات النشاط");
      qc.invalidateQueries({ queryKey: [["users", "list"]] });
    },
    onError: err => toast.error("تعذر تحديث الدور", { description: err.message }),
  });

  const canManage = user?.role === "admin";

  return (
    <div>
      <PageHeader
        title="الأدوار والصلاحيات"
        subtitle="فصل صريح بين وصول اللاعبين والمشرفين وإدارة النظام — تُفحص الأدوار من جهة الخادم في كل إجراء"
      />

      <div className="mb-4 flex flex-wrap gap-2">
        {Object.entries(ROLE_LABELS).map(([role, label]) => (
          <Badge key={role} variant="outline" className="border-border/60 gap-1 py-1.5">
            <KeyRound className="h-3 w-3 text-primary" /> {label}
          </Badge>
        ))}
      </div>

      <Card className="westoria-card border">
        <CardContent className="p-0">
          {isLoading ? (
            <p className="p-6 text-sm text-muted-foreground">جارٍ التحميل...</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">المستخدم</TableHead>
                    <TableHead className="text-right">البريد / الاسم</TableHead>
                    <TableHead className="text-right">Discord</TableHead>
                    <TableHead className="text-right">الدور الحالي</TableHead>
                    {canManage && <TableHead className="text-right">تغيير الدور</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data?.map(u => (
                    <TableRow key={u.id}>
                      <TableCell className="font-bold">#{u.id}</TableCell>
                      <TableCell>{u.name ?? u.email ?? "—"}</TableCell>
                      <TableCell dir="ltr" className="text-xs">{u.discordUsername ?? "—"}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="border-primary/40 text-primary">{ROLE_LABELS[u.role]}</Badge>
                      </TableCell>
                      {canManage && (
                        <TableCell>
                          <div className="flex gap-1.5">
                            {(["player", "staff", "admin"] as const).map(role => (
                              <Button
                                key={role}
                                size="sm"
                                variant={u.role === role ? "default" : "outline"}
                                disabled={u.id === user?.id || updateRole.isPending}
                                onClick={() => updateRole.mutate({ userId: u.id, role })}
                              >
                                {ROLE_LABELS[role]}
                              </Button>
                            ))}
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
