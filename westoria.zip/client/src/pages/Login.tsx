import { useQuery } from "@tanstack/react-query";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { ShieldCheck } from "lucide-react";
import { startLogin } from "@/const";

export default function Login() {
  const { data: user } = trpc.auth.me.useQuery();
  const { data: settings } = trpc.settings.get.useQuery(undefined, { enabled: !!user });
  const discordReady = settings?.discord.oauthConfigured ?? false;

  return (
    <div
      className="flex min-h-screen items-center justify-center px-4"
      dir="rtl"
      style={{
        background:
          "radial-gradient(ellipse at 50% 0%, oklch(0.25 0.06 255) 0%, oklch(0.16 0.02 260) 45%, oklch(0.13 0.015 260) 100%)",
      }}
    >
      <Card className="westoria-card w-full max-w-md">
        <CardContent className="flex flex-col items-center gap-6 p-10 text-center">
          <img src="/logo.png" alt="شعار ويستوريا" className="h-32 w-32 rounded-full westoria-glow" />
          <div>
            <h1 className="text-2xl font-extrabold tracking-wide">ويستوريا سيتي</h1>
            <p className="mt-1 text-sm text-muted-foreground">منصة إدارة الترقيات والأقسام — واجهة الويب الرسمية</p>
          </div>
          <div className="westoria-divider w-full" />
          <button
            onClick={() => startLogin()}
            className="w-full rounded-lg bg-primary px-6 py-3 text-sm font-extrabold text-primary-foreground transition hover:opacity-90 westoria-glow"
          >
            تسجيل الدخول إلى المنصة
          </button>
          <button
            onClick={() => {
              window.location.href = "/api/discord/login";
            }}
            disabled={!discordReady}
            className="w-full rounded-lg border border-border bg-secondary/60 px-6 py-3 text-sm font-bold text-foreground transition hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-40"
            title={discordReady ? "ربط حساب Discord" : "تكامل Discord غير مُهيأ بعد — يتطلب إعداد بيانات الاعتماد في الخادم"}
          >
            ربط / دخول عبر Discord
          </button>
          <p className="flex items-center gap-2 text-[11px] text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5" />
            جلستك محمية ولا تُشارك أي بيانات اعتماد مع المتصفح
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
