import { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { PageHeader, StatusBadge, ConfirmDialog } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { RefreshCcw, CheckCheck, ClipboardList } from "lucide-react";

type RequestRow = {
  request: {
    id: number;
    discordId: string;
    discordUsername: string | null;
    characterName: string;
    currentRank: string;
    requestedRank: string;
    supportingInfo: string | null;
    status: string;
    eligibilityReason: string | null;
    timeInRankDays: number | null;
    createdAt: string | Date;
  };
  departmentName: string | null;
  departmentType: string | null;
};

function RequestCard({
  row,
  selectable,
  selected,
  onToggle,
  onReevaluate,
  onReject,
}: {
  row: RequestRow;
  selectable: boolean;
  selected: boolean;
  onToggle: () => void;
  onReevaluate?: () => void;
  onReject?: () => void;
}) {
  const r = row.request;
  return (
    <div
      className={`rounded-xl border p-4 transition-all duration-200 ${
        selected ? "border-primary/60 westoria-glow" : "border-border/60"
      } bg-card/70`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          {selectable && (
            <Checkbox checked={selected} onCheckedChange={() => onToggle()} className="mt-1" aria-label={`اختيار طلب ${r.characterName}`} />
          )}
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-extrabold">{r.characterName}</span>
              <Badge variant="outline" className="border-border/60 text-muted-foreground">{row.departmentName ?? "قسم"}</Badge>
            </div>
            <div className="mt-1 text-sm text-muted-foreground">
              {r.currentRank} <span className="text-primary">←</span> {r.requestedRank}
            </div>
            <div className="mt-1 flex flex-wrap gap-x-3 text-[11px] text-muted-foreground" dir="auto">
              <span>Discord: {r.discordUsername ?? r.discordId}</span>
              {r.timeInRankDays !== null && <span>مدة اللقب: {r.timeInRankDays} يوماً</span>}
              <span>{new Date(r.createdAt).toLocaleDateString("ar")}</span>
            </div>
            {r.supportingInfo && <p className="mt-2 rounded-lg bg-secondary/40 px-3 py-2 text-xs leading-relaxed">{r.supportingInfo}</p>}
            {r.eligibilityReason && <p className="mt-2 text-xs text-muted-foreground">{r.eligibilityReason}</p>}
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <StatusBadge status={r.status} />
          {onReevaluate && (
            <Button variant="ghost" size="sm" onClick={onReevaluate}>
              <RefreshCcw className="h-3.5 w-3.5" /> إعادة تقييم
            </Button>
          )}
          {onReject && (
            <Button variant="ghost" size="sm" className="text-red-300" onClick={onReject}>
              رفض
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

export default function StaffPromotions() {
  const qc = useQueryClient();
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [confirmOpen, setConfirmOpen] = useState(false);

  const { data: eligible, isLoading: loadingEligible } = trpc.promotions.list.useQuery({
    status: "eligible",
  });
  const { data: pending } = trpc.promotions.list.useQuery({ status: "pending" });
  const { data: ineligible } = trpc.promotions.list.useQuery({ status: "ineligible" });
  const { data: completed } = trpc.promotions.list.useQuery({ status: "completed" });

  const reevaluate = trpc.promotions.reevaluate.useMutation({
    onSuccess: () => {
      toast.success("أُعيد تقييم الطلب");
      qc.invalidateQueries({ queryKey: [["promotions", "list"]] });
    },
    onError: err => toast.error("تعذر إعادة التقييم", { description: err.message }),
  });

  const reject = trpc.promotions.reject.useMutation({
    onSuccess: () => {
      toast.success("رُفض الطلب وسُجل الإجراء");
      qc.invalidateQueries({ queryKey: [["promotions", "list"]] });
    },
    onError: err => toast.error("تعذر رفض الطلب", { description: err.message }),
  });

  const bulkApprove = trpc.promotions.bulkApprove.useMutation({
    onSuccess: res => {
      const ok = res.results.filter(r => r.approved).length;
      toast.success(`تمت الموافقة على ${ok} طلباً وتسجيل النتائج وإشعار الأعضاء`);
      setSelected(new Set());
      setConfirmOpen(false);
      qc.invalidateQueries({ queryKey: [["promotions", "list"]] });
      qc.invalidateQueries({ queryKey: [["overview"]] });
      qc.invalidateQueries({ queryKey: [["audit", "list"]] });
    },
    onError: err => {
      toast.error("فشل التنفيذ الجماعي", { description: err.message });
      setConfirmOpen(false);
    },
  });

  const eligibleRows = useMemo(() => eligible ?? [], [eligible]);
  const selectedIds = useMemo(() => Array.from(selected), [selected]);

  const toggle = (id: number) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div>
      <PageHeader
        title="لوحة مشرفي الترقيات"
        subtitle="راجع الطلبات المؤهلة واعتمد عدة ترقيات في إجراء واحد مع تأكيد صريح"
      />

      {/* Selected review bar */}
      {selectedIds.length > 0 && (
        <Card className="westoria-card border mb-6 border-primary/40">
          <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
            <div className="flex items-center gap-2 text-sm font-bold">
              <ClipboardList className="h-4 w-4 text-primary" />
              محدد للمراجعة: {selectedIds.length} طلب —{" "}
              {eligibleRows
                .filter(r => selected.has(r.request.id))
                .map(r => r.request.characterName)
                .join("، ")}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setSelected(new Set())}>
                مسح التحديد
              </Button>
              <Button size="sm" className="westoria-glow" onClick={() => setConfirmOpen(true)}>
                <CheckCheck className="h-4 w-4" /> اعتماد جماعي
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="eligible" dir="rtl">
        <TabsList className="mb-4">
          <TabsTrigger value="eligible">مؤهلون ({eligibleRows.length})</TabsTrigger>
          <TabsTrigger value="pending">معلقون ({pending?.length ?? 0})</TabsTrigger>
          <TabsTrigger value="ineligible">غير مؤهلين ({ineligible?.length ?? 0})</TabsTrigger>
          <TabsTrigger value="completed">مكتملة ({completed?.length ?? 0})</TabsTrigger>
        </TabsList>

        <TabsContent value="eligible" className="space-y-3">
          {loadingEligible ? (
            <p className="text-sm text-muted-foreground">جارٍ التحميل...</p>
          ) : eligibleRows.length ? (
            eligibleRows.map(row => (
              <RequestCard
                key={row.request.id}
                row={row}
                selectable
                selected={selected.has(row.request.id)}
                onToggle={() => toggle(row.request.id)}
                onReject={() => reject.mutate({ id: row.request.id, reason: "مرفوض من قبل المشرف" })}
              />
            ))
          ) : (
            <Card className="westoria-card border"><CardContent className="p-6 text-sm text-muted-foreground">لا توجد طلبات مؤهلة حالياً.</CardContent></Card>
          )}
        </TabsContent>

        <TabsContent value="pending" className="space-y-3">
          {pending?.length ? (
            pending.map(row => (
              <RequestCard
                key={row.request.id}
                row={row}
                selectable={false}
                selected={false}
                onToggle={() => {}}
                onReevaluate={() => reevaluate.mutate({ id: row.request.id })}
              />
            ))
          ) : (
            <Card className="westoria-card border"><CardContent className="p-6 text-sm text-muted-foreground">لا توجد طلبات معلقة.</CardContent></Card>
          )}
        </TabsContent>

        <TabsContent value="ineligible" className="space-y-3">
          {ineligible?.length ? (
            ineligible.map(row => (
              <RequestCard
                key={row.request.id}
                row={row}
                selectable={false}
                selected={false}
                onToggle={() => {}}
                onReevaluate={() => reevaluate.mutate({ id: row.request.id })}
                onReject={() => reject.mutate({ id: row.request.id, reason: "مرفوض من قبل المشرف" })}
              />
            ))
          ) : (
            <Card className="westoria-card border"><CardContent className="p-6 text-sm text-muted-foreground">لا توجد طلبات غير مؤهلة.</CardContent></Card>
          )}
        </TabsContent>

        <TabsContent value="completed" className="space-y-3">
          {completed?.length ? (
            completed.map(row => (
              <RequestCard key={row.request.id} row={row} selectable={false} selected={false} onToggle={() => {}} />
            ))
          ) : (
            <Card className="westoria-card border"><CardContent className="p-6 text-sm text-muted-foreground">لم تُنفذ أي ترقية بعد.</CardContent></Card>
          )}
        </TabsContent>
      </Tabs>

      <ConfirmDialog
        open={confirmOpen}
        title="تأكيد الموافقة الجماعية"
        description={`سيتم اعتماد ${selectedIds.length} طلب ترقية: تعيين رتب Discord المُهيأة، تسجيل النتيجة، وإشعار كل عضو. لا يمكن التراجع عن هذا الإجراء.`}
        confirmLabel="تنفيذ الموافقات"
        processing={bulkApprove.isPending}
        onConfirm={() => bulkApprove.mutate({ ids: selectedIds })}
        onCancel={() => setConfirmOpen(false)}
      />
    </div>
  );
}
