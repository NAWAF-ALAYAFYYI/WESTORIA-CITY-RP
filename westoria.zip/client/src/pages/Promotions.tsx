import { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader, StatusBadge } from "@/components/shared";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowUpCircle, CheckCircle2, XCircle } from "lucide-react";

export default function Promotions() {
  const qc = useQueryClient();
  const { data: user } = trpc.auth.me.useQuery();
  const { data: departments } = trpc.departments.list.useQuery();
  const { data: mine } = trpc.promotions.mine.useQuery();

  const [discordId, setDiscordId] = useState(user?.discordId ?? "");
  const [characterName, setCharacterName] = useState(user?.characterName ?? "");
  const [departmentId, setDepartmentId] = useState<string>("");
  const [currentRank, setCurrentRank] = useState<string>("");
  const [requestedRank, setRequestedRank] = useState<string>("");
  const [supportingInfo, setSupportingInfo] = useState("");

  const selectedDept = useMemo(
    () => departments?.find(d => d.id === Number(departmentId)),
    [departments, departmentId],
  );

  const submit = trpc.promotions.submit.useMutation({
    onSuccess: res => {
      if (res.eligibility.eligible) {
        toast.success("أُرسل طلبك وهو مؤهل — بانتظار موافقة مدير القسم", {
          description: res.eligibility.reason,
        });
      } else {
        toast.warning("أُرسل طلبك لكنه غير مؤهل حالياً", { description: res.eligibility.reason });
      }
      qc.invalidateQueries({ queryKey: [["promotions", "mine"]] });
    },
    onError: err => toast.error("تعذر إرسال الطلب", { description: err.message }),
  });

  const handleSubmit = () => {
    if (!discordId || !characterName || !departmentId || !currentRank || !requestedRank) {
      toast.error("أكمل جميع الحقول المطلوبة أولاً");
      return;
    }
    submit.mutate({
      discordId,
      characterName,
      departmentId: Number(departmentId),
      currentRank,
      requestedRank,
      supportingInfo: supportingInfo || undefined,
    });
  };

  return (
    <div>
      <PageHeader
        title="إدارة الترقيات"
        subtitle="قدّم طلب ترقية بصرياً دون أي أوامر — يُقيَّم الطلب تلقائياً وفق قواعد قسمك"
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="westoria-card border">
          <CardHeader className="flex flex-row items-center gap-2 pb-2">
            <ArrowUpCircle className="h-5 w-5 text-primary" />
            <CardTitle className="text-base font-bold">طلب ترقية جديد</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>معرف Discord</Label>
                <Input
                  dir="ltr"
                  placeholder="123456789012345678"
                  value={discordId}
                  onChange={e => setDiscordId(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>اسم الشخصية</Label>
                <Input placeholder="مثال: خالد العتيبي" value={characterName} onChange={e => setCharacterName(e.target.value)} />
              </div>
            </div>

            <div className="space-y-2">
              <Label>القسم</Label>
              <Select value={departmentId} onValueChange={v => { setDepartmentId(v); setCurrentRank(""); setRequestedRank(""); }}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر القسم" />
                </SelectTrigger>
                <SelectContent>
                  {departments?.filter(d => d.isActive).map(d => (
                    <SelectItem key={d.id} value={String(d.id)}>{d.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>الرتبة الحالية</Label>
                <Select value={currentRank} onValueChange={setCurrentRank} disabled={!selectedDept}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="اختر الرتبة" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedDept?.ranks.map(r => (
                      <SelectItem key={r} value={r}>{r}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>الرتبة المطلوبة</Label>
                <Select value={requestedRank} onValueChange={setRequestedRank} disabled={!selectedDept}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="اختر الرتبة" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedDept?.ranks.map(r => (
                      <SelectItem key={r} value={r}>{r}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {selectedDept && (
              <p className="rounded-lg border border-border/60 bg-secondary/40 px-3 py-2 text-xs text-muted-foreground">
                قاعدة القسم: مدة اللقب المطلوبة {selectedDept.minDaysInRank} يوماً، ويجب أن تكون الرتبة المطلوبة التالية مباشرة في هرم الرتب.
              </p>
            )}

            <div className="space-y-2">
              <Label>معلومات داعمة (اختياري)</Label>
              <Textarea
                rows={4}
                placeholder="إنجازاتك وسجل خدمتك خلال الفترة الأخيرة..."
                value={supportingInfo}
                onChange={e => setSupportingInfo(e.target.value)}
              />
            </div>

            <Button className="w-full westoria-glow" onClick={handleSubmit} disabled={submit.isPending}>
              {submit.isPending ? "جارٍ الإرسال..." : "إرسال طلب الترقية"}
            </Button>
          </CardContent>
        </Card>

        <Card className="westoria-card border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-bold">طلباتي السابقة</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {mine?.length ? (
              mine.map(({ request, departmentName }) => (
                <div key={request.id} className="rounded-lg border border-border/60 bg-card/60 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-bold">{departmentName ?? "قسم"}</span>
                    <StatusBadge status={request.status} />
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    {request.currentRank} ← {request.requestedRank} • {new Date(request.createdAt).toLocaleDateString("ar")}
                  </div>
                  {request.eligibilityReason && (
                    <div className="mt-2 flex items-start gap-1.5 text-xs">
                      {request.status === "eligible" || request.status === "completed" || request.status === "approved" ? (
                        <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                      ) : request.status === "ineligible" || request.status === "rejected" ? (
                        <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-400" />
                      ) : null}
                      <span className="text-muted-foreground">{request.eligibilityReason}</span>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">لا توجد طلبات بعد — قدّم طلبك الأول من النموذج.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
