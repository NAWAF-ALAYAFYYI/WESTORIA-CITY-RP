import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CheckCircle2 } from "lucide-react";

/**
 * Public, link-shareable join application page (shared inside Discord).
 * No login required — submissions land in the staff Applications tab.
 */
export default function Apply() {
  const { data: departments } = trpc.departments.publicList.useQuery();
  const submit = trpc.applications.submit.useMutation({});

  const [form, setForm] = useState({
    discordId: "",
    characterName: "",
    age: "",
    timezone: "",
    experience: "",
    motivation: "",
    departmentId: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (!form.discordId || !form.characterName || !form.motivation) {
      toast.error("أكمل الحقول المطلوبة: معرف Discord، اسم الشخصية، والدوافع");
      return;
    }
    submit.mutate(
      {
        discordId: form.discordId,
        characterName: form.characterName,
        age: form.age ? Number(form.age) : undefined,
        timezone: form.timezone || undefined,
        experience: form.experience || undefined,
        motivation: form.motivation,
        departmentId: form.departmentId ? Number(form.departmentId) : undefined,
      },
      {
        onSuccess: () => setSubmitted(true),
        onError: err => toast.error("تعذر إرسال الطلب", { description: err.message }),
      },
    );
  };

  return (
    <div
      className="flex min-h-screen items-center justify-center px-4 py-10"
      dir="rtl"
      style={{
        background:
          "radial-gradient(ellipse at 50% 0%, oklch(0.25 0.06 255) 0%, oklch(0.16 0.02 260) 45%, oklch(0.13 0.015 260) 100%)",
      }}
    >
      <Card className="westoria-card w-full max-w-xl">
        <CardContent className="p-8">
          {submitted ? (
            <div className="flex flex-col items-center gap-4 py-8 text-center">
              <CheckCircle2 className="h-16 w-16 text-emerald-400" />
              <h1 className="text-xl font-extrabold">وصل طلبك بنجاح</h1>
              <p className="text-sm text-muted-foreground">
                سيراجع طلبك من إدارة مدينة ويستوريا قريباً، وستُخطرك إدارة السيرفر بالنتيجة.
              </p>
            </div>
          ) : (
            <>
              <div className="flex flex-col items-center gap-3 text-center">
                <img src="/logo.png" alt="شعار ويستوريا" className="h-24 w-24 rounded-full westoria-glow" />
                <h1 className="text-xl font-extrabold">طلب انضمام — ويستوريا سيتي</h1>
                <p className="text-sm text-muted-foreground">
                  املأ النموذج وسيصل طلبك مباشرة إلى إدارة المدينة للمراجعة
                </p>
                <div className="westoria-divider w-full" />
              </div>

              <div className="mt-6 space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>معرف Discord *</Label>
                    <Input dir="ltr" placeholder="123456789012345678" value={form.discordId} onChange={e => setForm(f => ({ ...f, discordId: e.target.value }))} />
                  </div>
                  <div className="space-y-2">
                    <Label>اسم الشخصية *</Label>
                    <Input placeholder="مثال: سلطان الحربي" value={form.characterName} onChange={e => setForm(f => ({ ...f, characterName: e.target.value }))} />
                  </div>
                  <div className="space-y-2">
                    <Label>العمر</Label>
                    <Input type="number" min={10} max={100} value={form.age} onChange={e => setForm(f => ({ ...f, age: e.target.value }))} />
                  </div>
                  <div className="space-y-2">
                    <Label>المنطقة الزمنية</Label>
                    <Input dir="ltr" placeholder="GMT+3" value={form.timezone} onChange={e => setForm(f => ({ ...f, timezone: e.target.value }))} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>القسم المرغوب</Label>
                  <Select value={form.departmentId} onValueChange={v => setForm(f => ({ ...f, departmentId: v }))}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="اختر القسم (اختياري)" />
                    </SelectTrigger>
                    <SelectContent>
                      {departments?.map(d => (
                        <SelectItem key={d.id} value={String(d.id)}>{d.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>خبرتك السابقة (اختياري)</Label>
                  <Textarea rows={3} placeholder="سيرفرات سابقة وأدوار..." value={form.experience} onChange={e => setForm(f => ({ ...f, experience: e.target.value }))} />
                </div>

                <div className="space-y-2">
                  <Label>لماذا تريد الانضمام إلى ويستوريا؟ *</Label>
                  <Textarea rows={4} placeholder="اكتب دوافعك بوضوح..." value={form.motivation} onChange={e => setForm(f => ({ ...f, motivation: e.target.value }))} />
                </div>

                <Button className="w-full westoria-glow" onClick={handleSubmit} disabled={submit.isPending}>
                  {submit.isPending ? "جارٍ الإرسال..." : "إرسال الطلب للإدارة"}
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
