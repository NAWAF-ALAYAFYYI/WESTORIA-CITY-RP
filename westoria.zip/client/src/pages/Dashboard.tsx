import { useQuery } from "@tanstack/react-query";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader, StatusBadge } from "@/components/shared";
import { Users, Building2, ArrowUpCircle, CheckCircle2, Clock, FileText, ShieldAlert, ScrollText } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

export default function Dashboard() {
  const { data, isLoading } = trpc.overview.useQuery();

  const stats = [
    { title: "المواطنون المسجلون", value: data?.citizens ?? 0, icon: Users },
    { title: "الأقسام المُهيأة", value: data?.departments ?? 0, icon: Building2 },
    { title: "طلبات مؤهلة بانتظار الموافقة", value: data?.eligible ?? 0, icon: ArrowUpCircle },
    { title: "طلبات قيد التقييم", value: data?.pending ?? 0, icon: Clock },
    { title: "ترقيات منجزة", value: data?.completed ?? 0, icon: CheckCircle2 },
    { title: "طلبات انضمام مفتوحة", value: data?.openApplications ?? 0, icon: FileText },
  ];

  const chartData = [
    { name: "مؤهلة", count: data?.eligible ?? 0 },
    { name: "قيد التقييم", count: data?.pending ?? 0 },
    { name: "غير مؤهلة", count: data?.ineligible ?? 0 },
    { name: "منجزة", count: data?.completed ?? 0 },
  ];

  return (
    <div>
      <PageHeader title="نظرة عامة" subtitle="أرقام المدينة لحظة بلحظة — الترقيات والأقسام وسجلات النشاط" />

      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
        {stats.map(stat => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title} className="westoria-card border">
              <CardContent className="flex flex-col gap-2 p-4">
                <Icon className="h-5 w-5 text-primary" />
                <div className="text-2xl font-extrabold tabular-nums">{stat.value}</div>
                <div className="text-[11px] leading-tight text-muted-foreground">{stat.title}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Card className="westoria-card border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-bold">حالة طلبات الترقيات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.7 0.03 255 / 12%)" />
                  <XAxis dataKey="name" tick={{ fill: "oklch(0.68 0.02 258)", fontSize: 12 }} />
                  <YAxis tick={{ fill: "oklch(0.68 0.02 258)", fontSize: 12 }} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      background: "oklch(0.21 0.025 260)",
                      border: "1px solid oklch(0.7 0.03 255 / 20%)",
                      borderRadius: 12,
                      color: "oklch(0.93 0.01 250)",
                    }}
                  />
                  <Bar dataKey="count" fill="oklch(0.68 0.17 252)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="westoria-card border">
          <CardHeader className="flex flex-row items-center gap-2 pb-2">
            <ScrollText className="h-4 w-4 text-primary" />
            <CardTitle className="text-base font-bold">أحدث الأنشطة</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {isLoading ? (
              <p className="text-sm text-muted-foreground">جارٍ التحميل...</p>
            ) : data?.recentLogs?.length ? (
              data.recentLogs.map(log => (
                <div key={log.id} className="flex items-center justify-between gap-3 rounded-lg border border-border/60 bg-card/60 px-3 py-2">
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold">{log.action}</div>
                    <div className="text-[11px] text-muted-foreground">
                      {log.actorName ?? "نظام"} — {new Date(log.createdAt).toLocaleString("ar")}
                    </div>
                  </div>
                  {log.entityType === "promotion_request" && <StatusBadge status="pending" />}
                </div>
              ))
            ) : (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <ShieldAlert className="h-4 w-4" />
                لا توجد أنشطة مسجلة بعد
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
