import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/shared";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bot, CheckCircle2, ShieldAlert, XCircle } from "lucide-react";

/**
 * System settings: honest Discord integration status. The page never claims
 * the integration is complete — it reads live readiness flags from the
 * server, and secrets themselves are configured as project environment
 * secrets only (never in frontend code).
 */
export default function Settings() {
  const qc = useQueryClient();
  const { data, isLoading } = trpc.settings.get.useQuery();

  const save = trpc.settings.update.useMutation({
    onSuccess: () => {
      toast.success("حُفظ الإعداد");
      qc.invalidateQueries({ queryKey: [["settings", "get"]] });
    },
    onError: err => toast.error("تعذر الحفظ", { description: err.message }),
  });

  const discord = data?.discord;
  const botReady = discord?.botConfigured ?? false;
  const oauthReady = discord?.oauthConfigured ?? false;

  return (
    <div>
      <PageHeader title="إعدادات النظام" subtitle="حالة تكامل Discord وقيم العرض العامة للمنصة" />

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="westoria-card border">
          <CardHeader className="flex flex-row items-center gap-2 pb-2">
            <Bot className="h-5 w-5 text-primary" />
            <CardTitle className="text-base font-bold">تكامل Discord</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border border-border/60 bg-card/60 px-3 py-2.5">
              <div>
                <div className="text-sm font-bold">OAuth2 لتسجيل الدخول</div>
                <div className="text-xs text-muted-foreground">DISCORD_CLIENT_ID / DISCORD_CLIENT_SECRET</div>
              </div>
              {oauthReady ? (
                <Badge variant="outline" className="border-emerald-500/30 text-emerald-300 gap-1">
                  <CheckCircle2 className="h-3 w-3" /> مُهيأ
                </Badge>
              ) : (
                <Badge variant="outline" className="border-amber-500/30 text-amber-300 gap-1">
                  <XCircle className="h-3 w-3" /> غير مُهيأ
                </Badge>
              )}
            </div>
            <div className="flex items-center justify-between rounded-lg border border-border/60 bg-card/60 px-3 py-2.5">
              <div>
                <div className="text-sm font-bold">بوت تعيين الرتب والإشعارات</div>
                <div className="text-xs text-muted-foreground">DISCORD_BOT_TOKEN / DISCORD_GUILD_ID</div>
              </div>
              {botReady ? (
                <Badge variant="outline" className="border-emerald-500/30 text-emerald-300 gap-1">
                  <CheckCircle2 className="h-3 w-3" /> مُهيأ
                </Badge>
              ) : (
                <Badge variant="outline" className="border-amber-500/30 text-amber-300 gap-1">
                  <XCircle className="h-3 w-3" /> غير مُهيأ
                </Badge>
              )}
            </div>
            <p className="flex items-start gap-2 rounded-lg bg-secondary/40 px-3 py-2 text-xs leading-relaxed text-muted-foreground">
              <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              الرموز السرية (توكن البوت وأسرار OAuth) تُضبط كأسرار بيئة الخادم فقط ولا تظهر أبداً في كود الواجهة. حتى إدخال بيانات حقيقية والتحقق من عملياتها الفعلية (تعيين رتبة حقيقية وإشعار حقيقي)، تظل حالة التكامل «غير مكتملة» بصدق. راجع دليل الإعداد SETUP.md للخطوات كاملة.
            </p>
          </CardContent>
        </Card>

        <Card className="westoria-card border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-bold">قيم عرض عامة</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>اسم المجتمع المعروض</Label>
              <Input
                dir="ltr"
                placeholder="WESTORIA CITY RP"
                defaultValue={(data?.settings?.brandName as string) ?? ""}
                onBlur={e =>
                  save.mutate({ key: "brandName", value: { value: e.target.value } })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>رابط سيرفر Discord المعروض</Label>
              <Input
                dir="ltr"
                placeholder="https://discord.gg/..."
                defaultValue={(data?.settings?.discordInvite as string) ?? ""}
                onBlur={e =>
                  save.mutate({ key: "discordInvite", value: { value: e.target.value } })
                }
              />
            </div>
            <p className="text-xs text-muted-foreground">تُحفظ القيم فور مغادرة الحقل وتُسجل في سجلات النشاط.</p>
          </CardContent>
        </Card>
      </div>

      {isLoading && <p className="mt-4 text-sm text-muted-foreground">جارٍ التحميل...</p>}
    </div>
  );
}
