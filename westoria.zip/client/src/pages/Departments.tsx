import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader, DEPARTMENT_TYPE_LABELS } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Building2, Pencil, Plus, Star, X } from "lucide-react";

interface DeptForm {
  id?: number;
  key: string;
  name: string;
  description: string;
  type: "military" | "government" | "civilian";
  discordRoleId: string;
  ranks: string[];
  minDaysInRank: number;
  managerUserIds: number[];
  isActive: boolean;
}

const EMPTY_FORM: DeptForm = {
  key: "",
  name: "",
  description: "",
  type: "military",
  discordRoleId: "",
  ranks: [],
  minDaysInRank: 7,
  managerUserIds: [],
  isActive: true,
};

export default function Departments({ type }: { type: "military" | "government" | "civilian" }) {
  const qc = useQueryClient();
  const { data: departments, isLoading } = trpc.departments.list.useQuery();
  const { data: users } = trpc.users.list.useQuery();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<DeptForm>(EMPTY_FORM);
  const [newRank, setNewRank] = useState("");

  const list = departments?.filter(d => d.type === type) ?? [];

  const onSaved = {
    onSuccess: () => {
      toast.success("حُفظ القسم بنجاح");
      setDialogOpen(false);
      qc.invalidateQueries({ queryKey: [["departments", "list"]] });
    },
    onError: (err: { message: string }) => toast.error("تعذر الحفظ", { description: err.message }),
  };
  const create = trpc.departments.create.useMutation(onSaved);
  const update = trpc.departments.update.useMutation(onSaved);

  const save = (input: DeptForm) => {
    const payload = {
      key: input.key,
      name: input.name,
      description: input.description || undefined,
      type: input.type,
      discordRoleId: input.discordRoleId || null,
      ranks: input.ranks,
      minDaysInRank: Number(input.minDaysInRank),
      managerUserIds: input.managerUserIds,
      isActive: input.isActive,
    };
    if (input.id) update.mutate({ ...payload, id: input.id });
    else create.mutate(payload);
  };

  const openEdit = (dept?: (typeof list)[number]) => {
    setForm(
      dept
        ? {
            id: dept.id,
            key: dept.key,
            name: dept.name,
            description: dept.description ?? "",
            type: dept.type,
            discordRoleId: dept.discordRoleId ?? "",
            ranks: dept.ranks ?? [],
            minDaysInRank: dept.minDaysInRank,
            managerUserIds: dept.managerUserIds ?? [],
            isActive: dept.isActive,
          }
        : { ...EMPTY_FORM, type },
    );
    setDialogOpen(true);
  };

  const addRank = () => {
    const v = newRank.trim();
    if (!v) return;
    if (form.ranks.includes(v)) {
      toast.error("الرتبة موجودة بالفعل");
      return;
    }
    setForm(f => ({ ...f, ranks: [...f.ranks, v] }));
    setNewRank("");
  };

  return (
    <div>
      <PageHeader
        title={DEPARTMENT_TYPE_LABELS[type]}
        subtitle="هيئة كل قسم: هرم الرتب، قواعد الأهلية، معرف رتبة Discord، والمدراء المخولون"
      />

      <div className="mb-4 flex justify-end">
        <Button onClick={() => openEdit()} className="westoria-glow">
          <Plus className="h-4 w-4" /> قسم جديد
        </Button>
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">جارٍ التحميل...</p>
      ) : list.length ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {list.map(dept => (
            <Card key={dept.id} className="westoria-card border">
              <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                <CardTitle className="flex items-center gap-2 text-base font-bold">
                  <Building2 className="h-4 w-4 text-primary" /> {dept.name}
                </CardTitle>
                <Button variant="ghost" size="icon" onClick={() => openEdit(dept)} aria-label="تعديل">
                  <Pencil className="h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                {dept.description && <p className="text-muted-foreground">{dept.description}</p>}
                <div>
                  <div className="mb-1 text-xs font-bold text-muted-foreground">هرم الرتب (تصاعدياً)</div>
                  <div className="flex flex-wrap gap-1.5">
                    {dept.ranks.map((rank, i) => (
                      <Badge key={rank} variant="outline" className="border-border/60 gap-1">
                        <Star className="h-3 w-3 text-primary" style={{ opacity: 0.35 + i * 0.1 }} />
                        {rank}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                  <span>مدة اللقب: {dept.minDaysInRank} يوماً</span>
                  <span dir="ltr">Discord: {dept.discordRoleId ? dept.discordRoleId : "غير مُهيأ"}</span>
                  <span>المدراء: {dept.managerUserIds?.length ? `${dept.managerUserIds.length} مخولين` : "لا أحد"}</span>
                </div>
                <Badge variant="outline" className={dept.isActive ? "border-emerald-500/30 text-emerald-300" : "border-red-500/30 text-red-300"}>
                  {dept.isActive ? "مُفعّل" : "معطل"}
                </Badge>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="westoria-card border"><CardContent className="p-8 text-center text-sm text-muted-foreground">لا توجد أقسام في هذا القطاع بعد — أنشئ أول قسم.</CardContent></Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>{form.id ? "تعديل قسم" : "قسم جديد"}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>الاسم</Label>
              <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>المفتاح (لاتيني)</Label>
              <Input dir="ltr" value={form.key} disabled={!!form.id} onChange={e => setForm(f => ({ ...f, key: e.target.value }))} />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label>الوصف</Label>
              <Textarea rows={2} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>معرف رتبة Discord (Role ID)</Label>
              <Input dir="ltr" placeholder="1234567890123456789" value={form.discordRoleId} onChange={e => setForm(f => ({ ...f, discordRoleId: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>مدة اللقب (أيام)</Label>
              <Input type="number" min={0} value={form.minDaysInRank} onChange={e => setForm(f => ({ ...f, minDaysInRank: Number(e.target.value) }))} />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label>هرم الرتب (الأدنى أولاً)</Label>
              <div className="flex gap-2">
                <Input
                  placeholder="أضف رتبة واضغط إضافة"
                  value={newRank}
                  onChange={e => setNewRank(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addRank();
                    }
                  }}
                />
                <Button type="button" variant="secondary" onClick={addRank}>إضافة</Button>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {form.ranks.map((rank, i) => (
                  <Badge key={`${rank}-${i}`} variant="outline" className="gap-1">
                    {i + 1}. {rank}
                    <X
                      className="h-3 w-3 cursor-pointer text-red-300"
                      onClick={() => setForm(f => ({ ...f, ranks: f.ranks.filter((_, j) => j !== i) }))}
                    />
                  </Badge>
                ))}
              </div>
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label>المدراء المخولون</Label>
              <div className="max-h-32 space-y-1 overflow-y-auto rounded-lg border border-border/60 p-2">
                {users?.filter(u => u.role !== "player").map(u => (
                  <label key={u.id} className="flex items-center gap-2 rounded px-2 py-1 text-sm hover:bg-secondary/50">
                    <input
                      type="checkbox"
                      checked={form.managerUserIds.includes(u.id)}
                      onChange={e =>
                        setForm(f => ({
                          ...f,
                          managerUserIds: e.target.checked
                            ? [...f.managerUserIds, u.id]
                            : f.managerUserIds.filter(id => id !== u.id),
                        }))
                      }
                    />
                    {u.name ?? u.email ?? u.id} — {u.role === "admin" ? "مدير النظام" : "مشرف"}
                  </label>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-2 sm:col-span-2">
              <Switch checked={form.isActive} onCheckedChange={v => setForm(f => ({ ...f, isActive: v }))} id="active" />
              <Label htmlFor="active">القسم مُفعّل ويقبل طلبات الترقية</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={() => save(form)} disabled={create.isPending || update.isPending}>
              {create.isPending || update.isPending ? "جارٍ الحفظ..." : "حفظ القسم"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
