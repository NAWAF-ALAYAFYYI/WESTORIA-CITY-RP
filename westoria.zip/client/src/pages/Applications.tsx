import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { PageHeader, StatusBadge } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Check, FileText, X } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function Applications() {
  const qc = useQueryClient();
  const [copied, setCopied] = useState(false);
  const { data, isLoading } = trpc.applications.list.useQuery();

  const applyLink = `${window.location.origin}/apply`;
  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(applyLink);
      setCopied(true);
      toast.success("نُسخ رابط التقديم — شاركه في الدسكورد");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("انسخ الرابط يدوياً من الحقل");
    }
  };

  const review = trpc.applications.review.useMutation({
    onSuccess: () => {
      toast.success("سُجل القرار في سجلات النشاط");
      qc.invalidateQueries({ queryKey: [["applications", "list"]] });
    },
    onError: err => toast.error("تعذر تسجيل القرار", { description: err.message }),
  });

  return (
    <div>
      <PageHeader
        title="طلبات الانضمام — مراجعة فقط"
        subtitle="تصل الطلبات من نموذج الرابط الذي يُشارك في الدسكورد، ومهمتك هنا الرفض أو القبول فقط"
      />

      <div className="mb-4 flex flex-wrap items-center gap-2 rounded-xl border border-primary/30 bg-primary/5 p-3">
        <FileText className="h-4 w-4 shrink-0 text-primary" />
        <span className="text-sm font-bold">رابط التقديم للاعبين:</span>
        <Input dir="ltr" readOnly value={applyLink} onFocus={e => e.target.select()} className="h-9 flex-1 min-w-[220px] bg-background/60" />
        <Button size="sm" onClick={copyLink} className="westoria-glow">
          {copied ? "تم النسخ" : "نسخ الرابط"}
        </Button>
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">جارٍ التحميل...</p>
      ) : data?.length ? (
        <div className="grid gap-4 md:grid-cols-2">
          {data.map(({ application: app, departmentName }) => (
            <Card key={app.id} className="westoria-card border">
              <CardContent className="space-y-3 p-5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 font-extrabold">
                    <FileText className="h-4 w-4 text-primary" /> {app.characterName}
                  </div>
                  <StatusBadge status={app.status} />
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                  <span dir="ltr">Discord: {app.discordId}</span>
                  <span>العمر: {app.age ?? "—"}</span>
                  <span>القسم المرغوب: {departmentName ?? "غير محدد"}</span>
                  <span>{new Date(app.createdAt).toLocaleDateString("ar")}</span>
                </div>
                {app.experience && (
                  <p className="rounded-lg bg-secondary/40 px-3 py-2 text-xs leading-relaxed">
                    <span className="font-bold">الخبرة: </span>{app.experience}
                  </p>
                )}
                <p className="rounded-lg bg-secondary/40 px-3 py-2 text-xs leading-relaxed">
                  <span className="font-bold">الدوافع: </span>{app.motivation}
                </p>
                {app.status === "pending" && (
                  <div className="flex gap-2 pt-1">
                    <Button size="sm" className="flex-1" onClick={() => review.mutate({ id: app.id, status: "accepted" })}>
                      <Check className="h-4 w-4" /> قبول
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 text-red-300" onClick={() => review.mutate({ id: app.id, status: "rejected" })}>
                      <X className="h-4 w-4" /> رفض
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="westoria-card border"><CardContent className="p-10 text-center text-sm text-muted-foreground">لا توجد طلبات انضمام بعد.</CardContent></Card>
      )}
    </div>
  );
}
