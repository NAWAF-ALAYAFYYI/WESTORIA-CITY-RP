import {
  boolean,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["player", "staff", "admin"]).default("player").notNull(),
  // Discord identity (filled via Discord OAuth2 when configured)
  discordId: varchar("discordId", { length: 32 }),
  discordUsername: varchar("discordUsername", { length: 128 }),
  discordAvatar: varchar("discordAvatar", { length: 256 }),
  characterName: varchar("characterName", { length: 128 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Department / job sector types (military, government, civilian). */
export const departments = mysqlTable("departments", {
  id: int("id").autoincrement().primaryKey(),
  /** Unique short key, e.g. "police", "mechanics". */
  key: varchar("key", { length: 64 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", [
    "military", // الأقسام العسكرية: الشرطة، المرور، الوقاية المدنية، الخدمات الطبية
    "government", // القطاعات الحكومية
    "civilian", // الوظائف المدنية: ميكانيكيون، أعمال تجارية وغيرها
  ]).notNull(),
  /** Discord role ID granted to members of this department. */
  discordRoleId: varchar("discordRoleId", { length: 64 }),
  /** Rank hierarchy ordered ascending (index 0 = lowest rank). */
  ranks: json("ranks").$type<string[]>().notNull(),
  /** Minimum days required in current rank before promotion eligibility. */
  minDaysInRank: int("minDaysInRank").notNull().default(7),
  /** User ids (database ids) of authorized promotion managers for this department. */
  managerUserIds: json("managerUserIds").$type<number[]>().notNull(),
  isActive: boolean("isActive").notNull().default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Department = typeof departments.$inferSelect;
export type InsertDepartment = typeof departments.$inferInsert;

/** Promotion requests submitted by players through the web form. */
export const promotionRequests = mysqlTable("promotion_requests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  discordId: varchar("discordId", { length: 32 }).notNull(),
  discordUsername: varchar("discordUsername", { length: 128 }),
  characterName: varchar("characterName", { length: 128 }).notNull(),
  departmentId: int("departmentId").notNull(),
  currentRank: varchar("currentRank", { length: 128 }).notNull(),
  requestedRank: varchar("requestedRank", { length: 128 }).notNull(),
  supportingInfo: text("supportingInfo"),
  status: mysqlEnum("status", [
    "pending", // بانتظار التقييم
    "eligible", // مؤهل — بانتظار الموافقة
    "ineligible", // غير مؤهل
    "approved", // تمت الموافقة (بانتظار تنفيذ الرتبة على Discord)
    "rejected", // مرفوض
    "completed", // منجز (تم تعيين الرتبة وإشعار العضو)
  ])
    .default("pending")
    .notNull(),
  eligibilityReason: text("eligibilityReason"),
  timeInRankDays: int("timeInRankDays"),
  reviewedByUserId: int("reviewedByUserId"),
  reviewedAt: timestamp("reviewedAt"),
  processedAt: timestamp("processedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PromotionRequest = typeof promotionRequests.$inferSelect;
export type InsertPromotionRequest = typeof promotionRequests.$inferInsert;

/** Citizen records (characters living in Westoria). */
export const citizens = mysqlTable("citizens", {
  id: int("id").autoincrement().primaryKey(),
  discordId: varchar("discordId", { length: 32 }).notNull().unique(),
  characterName: varchar("characterName", { length: 128 }).notNull(),
  departmentId: int("departmentId"),
  currentRank: varchar("currentRank", { length: 128 }),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
  notes: text("notes"),
  createdByUserId: int("createdByUserId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Citizen = typeof citizens.$inferSelect;
export type InsertCitizen = typeof citizens.$inferInsert;

/** Join applications to the community. */
export const applications = mysqlTable("applications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  discordId: varchar("discordId", { length: 32 }).notNull(),
  characterName: varchar("characterName", { length: 128 }).notNull(),
  age: int("age"),
  timezone: varchar("timezone", { length: 64 }),
  experience: text("experience"),
  motivation: text("motivation"),
  departmentId: int("departmentId"),
  status: mysqlEnum("status", ["pending", "accepted", "rejected"])
    .default("pending")
    .notNull(),
  reviewedByUserId: int("reviewedByUserId"),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;

/** Immutable audit trail for every sensitive action. */
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  actorUserId: int("actorUserId"),
  actorName: varchar("actorName", { length: 128 }),
  action: varchar("action", { length: 64 }).notNull(),
  entityType: varchar("entityType", { length: 64 }).notNull(),
  entityId: varchar("entityId", { length: 64 }),
  details: json("details").$type<Record<string, unknown>>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

/** Key/value system settings (non-secret configuration, e.g. Discord guild id). */
export const systemSettings = mysqlTable("system_settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 64 }).notNull().unique(),
  value: json("value").$type<Record<string, unknown>>(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertSystemSetting = typeof systemSettings.$inferInsert;
