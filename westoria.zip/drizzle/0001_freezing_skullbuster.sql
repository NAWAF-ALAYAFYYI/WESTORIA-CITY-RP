CREATE TABLE `applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`discordId` varchar(32) NOT NULL,
	`characterName` varchar(128) NOT NULL,
	`age` int,
	`timezone` varchar(64),
	`experience` text,
	`motivation` text,
	`departmentId` int,
	`status` enum('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
	`reviewedByUserId` int,
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `applications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorUserId` int,
	`actorName` varchar(128),
	`action` varchar(64) NOT NULL,
	`entityType` varchar(64) NOT NULL,
	`entityId` varchar(64),
	`details` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `citizens` (
	`id` int AUTO_INCREMENT NOT NULL,
	`discordId` varchar(32) NOT NULL,
	`characterName` varchar(128) NOT NULL,
	`departmentId` int,
	`currentRank` varchar(128),
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	`notes` text,
	`createdByUserId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `citizens_id` PRIMARY KEY(`id`),
	CONSTRAINT `citizens_discordId_unique` UNIQUE(`discordId`)
);
--> statement-breakpoint
CREATE TABLE `departments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(64) NOT NULL,
	`name` varchar(128) NOT NULL,
	`description` text,
	`type` enum('military','government','civilian') NOT NULL,
	`discordRoleId` varchar(64),
	`ranks` json NOT NULL,
	`minDaysInRank` int NOT NULL DEFAULT 7,
	`managerUserIds` json NOT NULL DEFAULT ('[]'),
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `departments_id` PRIMARY KEY(`id`),
	CONSTRAINT `departments_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
CREATE TABLE `promotion_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`discordId` varchar(32) NOT NULL,
	`discordUsername` varchar(128),
	`characterName` varchar(128) NOT NULL,
	`departmentId` int NOT NULL,
	`currentRank` varchar(128) NOT NULL,
	`requestedRank` varchar(128) NOT NULL,
	`supportingInfo` text,
	`status` enum('pending','eligible','ineligible','approved','rejected','completed') NOT NULL DEFAULT 'pending',
	`eligibilityReason` text,
	`timeInRankDays` int,
	`reviewedByUserId` int,
	`reviewedAt` timestamp,
	`processedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `promotion_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `system_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(64) NOT NULL,
	`value` json,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `system_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `system_settings_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('player','staff','admin') NOT NULL DEFAULT 'player';--> statement-breakpoint
ALTER TABLE `users` ADD `discordId` varchar(32);--> statement-breakpoint
ALTER TABLE `users` ADD `discordUsername` varchar(128);--> statement-breakpoint
ALTER TABLE `users` ADD `discordAvatar` varchar(256);--> statement-breakpoint
ALTER TABLE `users` ADD `characterName` varchar(128);