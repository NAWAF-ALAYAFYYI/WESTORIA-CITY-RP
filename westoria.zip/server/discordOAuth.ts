import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { parse as parseCookieHeader } from "cookie";
import type { Express, Request, Response } from "express";
import { randomBytes } from "crypto";
import * as db from "./db";
import { exchangeOAuthCode, getDiscordConfig, isDiscordOAuthConfigured } from "./discord";
import { getSessionCookieOptions } from "./_core/cookies";
import { sdk } from "./_core/sdk";

/**
 * Discord OAuth2 login routes.
 *
 * Activated only when DISCORD_CLIENT_ID / DISCORD_CLIENT_SECRET project
 * secrets are configured. The flow identifies the player's Discord identity
 * (id, username, avatar) and their membership in the configured guild, then
 * links it to the logged-in web session user. No tokens ever reach the
 * frontend.
 */

const DISCORD_STATE_COOKIE = "discord_oauth_state";

function baseUrl(req: Request): string {
  // Browser-facing URLs must stay relative; the redirect URI is registered
  // externally, so we derive it from platform-provided headers when present.
  const proto = (req.headers["x-forwarded-proto"] as string) || req.protocol || "https";
  const host = (req.headers["x-forwarded-host"] as string) || req.headers.host || "";
  return `${proto}://${host}`;
}

export function registerDiscordRoutes(app: Express) {
  // Starts the Discord OAuth2 authorization-code flow.
  app.get("/api/discord/login", (req: Request, res: Response) => {
    const { clientId, guildId } = getDiscordConfig();
    if (!isDiscordOAuthConfigured()) {
      res.status(503).json({ error: "تكامل Discord غير مُهيأ بعد — أضف بيانات الاعتماد في إعدادات النظام" });
      return;
    }
    const nonce = randomBytes(16).toString("hex");
    const cookieOptions = getSessionCookieOptions(req);
    res.cookie(DISCORD_STATE_COOKIE, nonce, { ...cookieOptions, maxAge: 10 * 60 * 1000 });

    const params = new URLSearchParams({
      client_id: clientId!,
      redirect_uri: `${baseUrl(req)}/api/discord/callback`,
      response_type: "code",
      scope: "identify guilds.members.read",
      state: nonce,
      prompt: "consent",
    });
    if (guildId) params.set("guild_id", guildId);
    res.redirect(302, `https://discord.com/oauth2/authorize?${params.toString()}`);
  });

  // Discord callback: verify state, exchange code, link identity to session user.
  app.get("/api/discord/callback", async (req: Request, res: Response) => {
    const code = typeof req.query.code === "string" ? req.query.code : undefined;
    const state = typeof req.query.state === "string" ? req.query.state : undefined;
    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }
    const expected = parseCookieHeader(req.headers.cookie ?? "")[DISCORD_STATE_COOKIE];
    if (!expected || expected !== state) {
      res.status(403).json({ error: "invalid oauth state" });
      return;
    }

    try {
      const result = await exchangeOAuthCode({
        code,
        redirectUri: `${baseUrl(req)}/api/discord/callback`,
      });
      if (!result) {
        res.status(503).json({ error: "تكامل Discord غير مُهيأ" });
        return;
      }
      const discordUser = result.user as {
        id: string;
        username?: string;
        global_name?: string;
        avatar?: string | null;
      };

      // Link to the current web session user (if logged in).
      const sessionCookie = parseCookieHeader(req.headers.cookie ?? "")[COOKIE_NAME];
      let openId: string | null = null;
      if (sessionCookie) {
        try {
          const session = await sdk.verifySession(sessionCookie);
          openId = session?.openId ?? null;
        } catch {
          openId = null;
        }
      }

      if (openId) {
        await db.upsertUser({
          openId,
          discordId: discordUser.id,
          discordUsername: discordUser.global_name || discordUser.username || null,
          discordAvatar: discordUser.avatar
            ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png`
            : null,
        });
        res.redirect(302, "/?discord=linked");
      } else {
        res.redirect(302, "/login?discord=login_required");
      }
    } catch (error) {
      console.error("[Discord OAuth] Callback failed:", error instanceof Error ? error.message : error);
      res.status(500).json({ error: "Discord OAuth callback failed" });
    }
  });
}
