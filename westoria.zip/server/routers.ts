import { COOKIE_NAME } from "@shared/const";
import { and, desc, eq, inArray, like, or, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getDb } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { logAudit } from "./audit";
import { evaluateEligibility } from "./eligibility";
import { assignRankRole, isBotConfigured, isDiscordOAuthConfigured, notifyMember } from "./discord";
import {
  applications,
  auditLogs,
  citizens,
  departments,
  promotionRequests,
  systemSettings,
  users,
} from "../drizzle/schema";

/**
 * Project owner bootstrap: the very first account to reach the platform is
 * promoted to admin automatically, so the owner always has full access.
 */
async function ensureOwnerAdmin<T extends { id: number; role: string; name: string | null }>(user: T) {
  if (user.role !== "player") return user;
  try {
    const db = await getDb();
    if (!db) return user;
    const admins = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.role, "admin"))
      .limit(1);
    if (admins.length > 0) return user;
    await db.update(users).set({ role: "admin" }).where(eq(users.id, user.id));
    await logAudit({
      actorUserId: user.id,
      actorName: user.name,
      action: "user.promote_first_admin",
      entityType: "user",
      entityId: String(user.id),
      details: { reason: "first account bootstrap" },
    });
    return { ...user, role: "admin" } as T;
  } catch {
    return user;
  }
}

/** Staff (or admin) procedure: separates ordinary players from staff access. */
const staffProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  ctx.user = await ensureOwnerAdmin(ctx.user);
  if (ctx.user.role !== "staff" && ctx.user.role !== "admin") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "هذه الصلاحية متاحة للمشرفين فقط (10003)",
    });
  }
  return next({ ctx });
});

const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  ctx.user = await ensureOwnerAdmin(ctx.user);
  if (ctx.user.role !== "admin") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "هذه الصلاحية متاحة للإدارة فقط (10004)",
    });
  }
  return next({ ctx });
});

/** Admin, or an authorized manager of the given department. */
function assertDepartmentManager(
  user: { id: number; role: string },
  department: { managerUserIds: number[] | null },
) {
  if (user.role === "admin") return;
  const managers = department.managerUserIds ?? [];
  if (!managers.includes(user.id)) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "أنت لست مديراً مخولاً لهذا القسم (10005)",
    });
  }
}

const departmentInput = z.object({
  key: z.string().min(2).max(64).regex(/^[a-z0-9-]+$/, "المفتاح بأحرف لاتينية صغيرة وشرطات فقط"),
  name: z.string().min(2).max(128),
  description: z.string().max(2000).optional(),
  type: z.enum(["military", "government", "civilian"]),
  discordRoleId: z.string().max(64).nullable().optional(),
  ranks: z.array(z.string().min(1).max(128)).min(1).max(30),
  minDaysInRank: z.number().int().min(0).max(3650),
  managerUserIds: z.array(z.number().int()).max(50),
  isActive: z.boolean(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(async opts => {
      if (!opts.ctx.user) return undefined;
      return ensureOwnerAdmin(opts.ctx.user);
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============================================================
  // Users & roles
  // ============================================================
  users: router({
    list: staffProcedure.query(async () => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      return db
        .select({
          id: users.id,
          name: users.name,
          email: users.email,
          role: users.role,
          discordId: users.discordId,
          discordUsername: users.discordUsername,
          characterName: users.characterName,
          lastSignedIn: users.lastSignedIn,
          createdAt: users.createdAt,
        })
        .from(users)
        .orderBy(desc(users.createdAt))
        .limit(500);
    }),
    updateRole: adminProcedure
      .input(z.object({ userId: z.number().int(), role: z.enum(["player", "staff", "admin"]) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        if (input.userId === ctx.user.id) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكنك تغيير دورك الخاص" });
        }
        const [target] = await db.select().from(users).where(eq(users.id, input.userId)).limit(1);
        if (!target) throw new TRPCError({ code: "NOT_FOUND", message: "المستخدم غير موجود" });
        await db.update(users).set({ role: input.role }).where(eq(users.id, input.userId));
        await logAudit({
          actorUserId: ctx.user.id,
          actorName: ctx.user.name,
          action: "user.role.update",
          entityType: "user",
          entityId: String(input.userId),
          details: { from: target.role, to: input.role },
        });
        return { success: true };
      }),
    updateMe: protectedProcedure
      .input(z.object({ characterName: z.string().min(2).max(128) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        await db.update(users).set({ characterName: input.characterName }).where(eq(users.id, ctx.user.id));
        return { success: true };
      }),
  }),

  // ============================================================
  // Departments (military / government / civilian)
  // ============================================================
  departments: router({
    /** Public: active department names for the shared /apply form. */
    publicList: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      return db
        .select({ id: departments.id, name: departments.name, type: departments.type })
        .from(departments)
        .where(eq(departments.isActive, true))
        .orderBy(departments.type, departments.name);
    }),
    list: protectedProcedure.query(async () => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      return db.select().from(departments).orderBy(departments.type, departments.name);
    }),
    create: adminProcedure.input(departmentInput).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const [dup] = await db.select().from(departments).where(eq(departments.key, input.key)).limit(1);
      if (dup) throw new TRPCError({ code: "CONFLICT", message: "يوجد قسم بنفس المفتاح" });
      const [created] = await db
        .insert(departments)
        .values({
          ...input,
          discordRoleId: input.discordRoleId || null,
          description: input.description || null,
        })
        .$returningId();
      await logAudit({
        actorUserId: ctx.user.id,
        actorName: ctx.user.name,
        action: "department.create",
        entityType: "department",
        entityId: String(created?.id ?? ""),
        details: { key: input.key, name: input.name, type: input.type },
      });
      return { success: true, id: created?.id };
    }),
    update: protectedProcedure
      .input(departmentInput.extend({ id: z.number().int() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        const [dept] = await db.select().from(departments).where(eq(departments.id, input.id)).limit(1);
        if (!dept) throw new TRPCError({ code: "NOT_FOUND", message: "القسم غير موجود" });
        assertDepartmentManager(ctx.user, dept);
        await db
          .update(departments)
          .set({
            name: input.name,
            description: input.description || null,
            type: input.type,
            discordRoleId: input.discordRoleId || null,
            ranks: input.ranks,
            minDaysInRank: input.minDaysInRank,
            managerUserIds: input.managerUserIds,
            isActive: input.isActive,
          })
          .where(eq(departments.id, input.id));
        await logAudit({
          actorUserId: ctx.user.id,
          actorName: ctx.user.name,
          action: "department.update",
          entityType: "department",
          entityId: String(input.id),
          details: { key: dept.key, name: input.name },
        });
        return { success: true };
      }),
  }),

  // ============================================================
  // Promotion management
  // ============================================================
  promotions: router({
    /** Public: promotion requests are submitted from Discord via the shareable /apply link. */
    submit: publicProcedure
      .input(
        z.object({
          discordId: z.string().min(5).max(32),
          discordUsername: z.string().max(128).optional(),
          characterName: z.string().min(2).max(128),
          departmentId: z.number().int(),
          currentRank: z.string().min(1).max(128),
          requestedRank: z.string().min(1).max(128),
          supportingInfo: z.string().max(4000).optional(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });

        const [dept] = await db.select().from(departments).where(eq(departments.id, input.departmentId)).limit(1);
        if (!dept) throw new TRPCError({ code: "NOT_FOUND", message: "القسم غير موجود" });

        // Prevent duplicate open requests for the same player + department.
        const [openRequest] = await db
          .select()
          .from(promotionRequests)
          .where(
            and(
              eq(promotionRequests.discordId, input.discordId),
              eq(promotionRequests.departmentId, input.departmentId),
              inArray(promotionRequests.status, ["pending", "eligible", "ineligible"]),
            ),
          )
          .limit(1);
        if (openRequest) {
          throw new TRPCError({
            code: "CONFLICT",
            message: "يوجد طلب ترقية مفتوح لنفس اللاعب في هذا القسم — انتظر نتيجته أولاً",
          });
        }

        const eligibility = await evaluateEligibility({
          department: dept,
          discordId: input.discordId,
          currentRank: input.currentRank,
          requestedRank: input.requestedRank,
        });

        const [created] = await db
          .insert(promotionRequests)
          .values({
            ...(ctx.user?.id ? { userId: ctx.user.id } : {}),
            discordId: input.discordId,
            discordUsername: input.discordUsername || ctx.user?.discordUsername || null,
            characterName: input.characterName,
            departmentId: input.departmentId,
            currentRank: input.currentRank,
            requestedRank: input.requestedRank,
            supportingInfo: input.supportingInfo || null,
            status: eligibility.eligible ? "eligible" : "ineligible",
            eligibilityReason: eligibility.reason,
            timeInRankDays: eligibility.timeInRankDays,
          })
          .$returningId();

        await logAudit({
          actorUserId: ctx.user?.id ?? null,
          actorName: ctx.user?.name ?? "مقدم طلب من Discord",
          action: "promotion.submit",
          entityType: "promotion_request",
          entityId: String(created?.id ?? ""),
          details: {
            characterName: input.characterName,
            department: dept.key,
            currentRank: input.currentRank,
            requestedRank: input.requestedRank,
            status: eligibility.eligible ? "eligible" : "ineligible",
            reason: eligibility.reason,
          },
        });

        return { success: true, id: created?.id, eligibility };
      }),

    /** The player's own requests. */
    mine: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const rows = await db
        .select({
          request: promotionRequests,
          departmentName: departments.name,
          departmentType: departments.type,
        })
        .from(promotionRequests)
        .leftJoin(departments, eq(promotionRequests.departmentId, departments.id))
        .where(eq(promotionRequests.userId, ctx.user.id))
        .orderBy(desc(promotionRequests.createdAt))
        .limit(50);
      return rows;
    }),

    /** Staff dashboard lists by status. */
    list: staffProcedure
      .input(z.object({ status: z.enum(["pending", "eligible", "ineligible", "approved", "completed", "rejected"]).optional() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        const base = db
          .select({
            request: promotionRequests,
            departmentName: departments.name,
            departmentType: departments.type,
            departmentDiscordRoleId: departments.discordRoleId,
          })
          .from(promotionRequests)
          .leftJoin(departments, eq(promotionRequests.departmentId, departments.id));
        const rows = input.status
          ? await base.where(eq(promotionRequests.status, input.status)).orderBy(desc(promotionRequests.createdAt)).limit(200)
          : await base.orderBy(desc(promotionRequests.createdAt)).limit(200);
        return rows;
      }),

    /** Staff re-evaluates a pending/ineligible request against current rules. */
    reevaluate: staffProcedure
      .input(z.object({ id: z.number().int() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        const [row] = await db
          .select({ request: promotionRequests, department: departments })
          .from(promotionRequests)
          .leftJoin(departments, eq(promotionRequests.departmentId, departments.id))
          .where(eq(promotionRequests.id, input.id))
          .limit(1);
        if (!row?.department) throw new TRPCError({ code: "NOT_FOUND", message: "الطلب غير موجود" });
        assertDepartmentManager(ctx.user, row.department);

        const eligibility = await evaluateEligibility({
          department: row.department,
          discordId: row.request.discordId,
          currentRank: row.request.currentRank,
          requestedRank: row.request.requestedRank,
        });
        const updated = await db
          .update(promotionRequests)
          .set({
            status: eligibility.eligible ? "eligible" : "ineligible",
            eligibilityReason: eligibility.reason,
            timeInRankDays: eligibility.timeInRankDays,
          })
          .where(
            and(
              eq(promotionRequests.id, input.id),
              inArray(promotionRequests.status, ["pending", "eligible", "ineligible"]),
            ),
          );
        if (!updated[0].affectedRows) {
          throw new TRPCError({ code: "CONFLICT", message: "تمت معالجة الطلب مسبقاً" });
        }

        await logAudit({
          actorUserId: ctx.user.id,
          actorName: ctx.user.name,
          action: "promotion.reevaluate",
          entityType: "promotion_request",
          entityId: String(input.id),
          details: { status: eligibility.eligible ? "eligible" : "ineligible", reason: eligibility.reason },
        });
        return { success: true, eligibility };
      }),

    /**
     * Bulk approval: authorized promotion managers select multiple eligible
     * players and approve them in one action. Each row is updated with a
     * conditional WHERE (status = 'eligible') so repeated processing of the
     * same request is impossible.
     */
    bulkApprove: staffProcedure
      .input(z.object({ ids: z.array(z.number().int()).min(1).max(100) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });

        const rows = await db
          .select({ request: promotionRequests, department: departments })
          .from(promotionRequests)
          .leftJoin(departments, eq(promotionRequests.departmentId, departments.id))
          .where(and(inArray(promotionRequests.id, input.ids), eq(promotionRequests.status, "eligible")));

        const results: Array<{ id: number; approved: boolean; detail: string }> = [];

        for (const row of rows) {
          const dept = row.department;
          if (!dept) {
            results.push({ id: row.request.id, approved: false, detail: "القسم غير موجود" });
            continue;
          }
          assertDepartmentManager(ctx.user, dept);

          // Conditional update: only requests still in 'eligible' pass.
          const updated = await db
            .update(promotionRequests)
            .set({ status: "approved", reviewedByUserId: ctx.user.id, reviewedAt: new Date(), processedAt: new Date() })
            .where(and(eq(promotionRequests.id, row.request.id), eq(promotionRequests.status, "eligible")))
          ;
          if (!updated[0].affectedRows) {
            results.push({ id: row.request.id, approved: false, detail: "تمت معالجة الطلب مسبقاً" });
            continue;
          }

          // Assign the configured Discord role (backend bot integration).
          const ranks = dept.ranks ?? [];
          const prevRankIndex = ranks.indexOf(row.request.currentRank);
          const roleResult = await assignRankRole({
            discordId: row.request.discordId,
            roleId: dept.discordRoleId,
            previousRoleId: null,
          });
          void prevRankIndex;

          // Notify the member.
          const notifyResult = await notifyMember({
            discordId: row.request.discordId,
            message: `مرحباً ${row.request.characterName}، تمت الموافقة على ترقيتك في ${dept.name} إلى رتبة «${row.request.requestedRank}». مبروك الترقية!`,
          });

          const discordReady = isBotConfigured();
          const finalStatus = roleResult.performed && roleResult.success ? "completed" : "approved";
          await db
            .update(promotionRequests)
            .set({
              status: finalStatus,
              eligibilityReason: roleResult.detail + (notifyResult.detail ? ` | ${notifyResult.detail}` : ""),
            })
            .where(eq(promotionRequests.id, row.request.id));

          // Keep the citizen record current.
          await db
            .insert(citizens)
            .values({
              discordId: row.request.discordId,
              characterName: row.request.characterName,
              departmentId: dept.id,
              currentRank: row.request.requestedRank,
            })
            .onDuplicateKeyUpdate({
              set: { departmentId: dept.id, currentRank: row.request.requestedRank },
            });

          await logAudit({
            actorUserId: ctx.user.id,
            actorName: ctx.user.name,
            action: "promotion.approve",
            entityType: "promotion_request",
            entityId: String(row.request.id),
            details: {
              characterName: row.request.characterName,
              department: dept.key,
              newRank: row.request.requestedRank,
              discordRoleAssigned: roleResult.success,
              discordNotified: notifyResult.success,
              discordReady,
            },
          });

          results.push({
            id: row.request.id,
            approved: true,
            detail: roleResult.success
              ? "تمت الموافقة وتعيين الرتبة على Discord"
              : "تمت الموافقة (تكامل Discord غير مُهيأ — لم تُنفذ عملية الرتبة)",
          });
        }

        return { success: true, results };
      }),

    reject: staffProcedure
      .input(z.object({ id: z.number().int(), reason: z.string().min(3).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        const [row] = await db
          .select({ request: promotionRequests, department: departments })
          .from(promotionRequests)
          .leftJoin(departments, eq(promotionRequests.departmentId, departments.id))
          .where(eq(promotionRequests.id, input.id))
          .limit(1);
        if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "الطلب غير موجود" });
        if (row.department) assertDepartmentManager(ctx.user, row.department);

        const updated = await db
          .update(promotionRequests)
          .set({
            status: "rejected",
            eligibilityReason: input.reason,
            reviewedByUserId: ctx.user.id,
            reviewedAt: new Date(),
          })
          .where(
            and(
              eq(promotionRequests.id, input.id),
              inArray(promotionRequests.status, ["pending", "eligible", "ineligible"]),
            ),
          );
        if (!updated[0].affectedRows) {
          throw new TRPCError({ code: "CONFLICT", message: "تمت معالجة الطلب مسبقاً" });
        }

        await notifyMember({
          discordId: row.request.discordId,
          message: `تم رفض طلب ترقيتك في ${row.department?.name ?? "القسم"}. السبب: ${input.reason}`,
        });

        await logAudit({
          actorUserId: ctx.user.id,
          actorName: ctx.user.name,
          action: "promotion.reject",
          entityType: "promotion_request",
          entityId: String(input.id),
          details: { characterName: row.request.characterName, reason: input.reason },
        });
        return { success: true };
      }),
  }),

  // ============================================================
  // Citizens
  // ============================================================
  citizens: router({
    list: staffProcedure
      .input(z.object({ search: z.string().max(128).optional() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        const base = db
          .select({ citizen: citizens, departmentName: departments.name })
          .from(citizens)
          .leftJoin(departments, eq(citizens.departmentId, departments.id));
        if (input.search) {
          const q = `%${input.search}%`;
          return base
            .where(or(like(citizens.characterName, q), like(citizens.discordId, q)))
            .orderBy(desc(citizens.createdAt))
            .limit(300);
        }
        return base.orderBy(desc(citizens.createdAt)).limit(300);
      }),
    upsert: staffProcedure
      .input(
        z.object({
          discordId: z.string().min(5).max(32),
          characterName: z.string().min(2).max(128),
          departmentId: z.number().int().nullable().optional(),
          currentRank: z.string().max(128).nullable().optional(),
          notes: z.string().max(4000).nullable().optional(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        await db
          .insert(citizens)
          .values({
            discordId: input.discordId,
            characterName: input.characterName,
            departmentId: input.departmentId ?? null,
            currentRank: input.currentRank ?? null,
            notes: input.notes ?? null,
            createdByUserId: ctx.user.id,
          })
          .onDuplicateKeyUpdate({
            set: {
              characterName: input.characterName,
              departmentId: input.departmentId ?? null,
              currentRank: input.currentRank ?? null,
              notes: input.notes ?? null,
            },
          });
        await logAudit({
          actorUserId: ctx.user.id,
          actorName: ctx.user.name,
          action: "citizen.upsert",
          entityType: "citizen",
          entityId: input.discordId,
          details: { characterName: input.characterName },
        });
        return { success: true };
      }),
  }),

  // ============================================================
  // Applications
  // ============================================================
  applications: router({
    /** Public: applications are submitted from Discord via the shareable /apply link. */
    submit: publicProcedure
      .input(
        z.object({
          discordId: z.string().min(5).max(32),
          characterName: z.string().min(2).max(128),
          age: z.number().int().min(10).max(100).optional(),
          timezone: z.string().max(64).optional(),
          experience: z.string().max(4000).optional(),
          motivation: z.string().min(10).max(4000),
          departmentId: z.number().int().nullable().optional(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        const [open] = await db
          .select()
          .from(applications)
          .where(and(eq(applications.discordId, input.discordId), eq(applications.status, "pending")))
          .limit(1);
        if (open) throw new TRPCError({ code: "CONFLICT", message: "لديك طلب انضمام قيد المراجعة بالفعل" });
        await db.insert(applications).values({ ...input, userId: ctx.user?.id ?? null });
        await logAudit({
          actorUserId: ctx.user?.id ?? null,
          actorName: ctx.user?.name ?? "مقدم طلب من Discord",
          action: "application.submit",
          entityType: "application",
          entityId: input.discordId,
          details: { characterName: input.characterName },
        });
        return { success: true };
      }),
    list: staffProcedure.query(async () => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      return db
        .select({ application: applications, departmentName: departments.name })
        .from(applications)
        .leftJoin(departments, eq(applications.departmentId, departments.id))
        .orderBy(desc(applications.createdAt))
        .limit(200);
    }),
    review: staffProcedure
      .input(z.object({ id: z.number().int(), status: z.enum(["accepted", "rejected"]) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        const updated = await db
          .update(applications)
          .set({ status: input.status, reviewedByUserId: ctx.user.id, reviewedAt: new Date() })
          .where(and(eq(applications.id, input.id), eq(applications.status, "pending")));
        if (!updated[0].affectedRows) {
          throw new TRPCError({ code: "CONFLICT", message: "تمت معالجة الطلب مسبقاً" });
        }
        await logAudit({
          actorUserId: ctx.user.id,
          actorName: ctx.user.name,
          action: "application.review",
          entityType: "application",
          entityId: String(input.id),
          details: { status: input.status },
        });
        return { success: true };
      }),
  }),

  // ============================================================
  // Audit logs
  // ============================================================
  audit: router({
    list: staffProcedure.query(async () => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      return db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(300);
    }),
  }),

  // ============================================================
  // System settings (Discord integration status etc.)
  // ============================================================
  settings: router({
    get: protectedProcedure.query(async () => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const rows = await db.select().from(systemSettings);
      const map: Record<string, unknown> = {};
      for (const row of rows) map[row.key] = row.value;
      return {
        settings: map,
        discord: {
          oauthConfigured: isDiscordOAuthConfigured(),
          botConfigured: isBotConfigured(),
        },
      };
    }),
    update: adminProcedure
      .input(z.object({ key: z.string().min(2).max(64), value: z.record(z.string(), z.unknown()) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
        await db
          .insert(systemSettings)
          .values({ key: input.key, value: input.value })
          .onDuplicateKeyUpdate({ set: { value: input.value } });
        await logAudit({
          actorUserId: ctx.user.id,
          actorName: ctx.user.name,
          action: "settings.update",
          entityType: "system_settings",
          entityId: input.key,
          details: {},
        });
        return { success: true };
      }),
  }),

  // ============================================================
  // Overview stats
  // ============================================================
  overview: staffProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
    const count = async (table: Parameters<typeof db.select>[0] extends never ? never : never) => table;
    void count;
    const [citizenCount] = await db.select({ n: sql<number>`count(*)` }).from(citizens);
    const [deptCount] = await db.select({ n: sql<number>`count(*)` }).from(departments);
    const [eligibleCount] = await db
      .select({ n: sql<number>`count(*)` })
      .from(promotionRequests)
      .where(eq(promotionRequests.status, "eligible"));
    const [pendingCount] = await db
      .select({ n: sql<number>`count(*)` })
      .from(promotionRequests)
      .where(eq(promotionRequests.status, "pending"));
    const [completedCount] = await db
      .select({ n: sql<number>`count(*)` })
      .from(promotionRequests)
      .where(inArray(promotionRequests.status, ["approved", "completed"]));
    const [ineligibleCount] = await db
      .select({ n: sql<number>`count(*)` })
      .from(promotionRequests)
      .where(eq(promotionRequests.status, "ineligible"));
    const [openApps] = await db
      .select({ n: sql<number>`count(*)` })
      .from(applications)
      .where(eq(applications.status, "pending"));
    const recentLogs = await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(8);
    return {
      citizens: Number(citizenCount?.n ?? 0),
      departments: Number(deptCount?.n ?? 0),
      eligible: Number(eligibleCount?.n ?? 0),
      pending: Number(pendingCount?.n ?? 0),
      completed: Number(completedCount?.n ?? 0),
      ineligible: Number(ineligibleCount?.n ?? 0),
      openApplications: Number(openApps?.n ?? 0),
      recentLogs,
    };
  }),
});

export type AppRouter = typeof appRouter;
