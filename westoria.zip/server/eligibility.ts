import { and, eq, inArray, max } from "drizzle-orm";
import { getDb } from "./db";
import {
  citizens,
  departments,
  promotionRequests,
  type Department,
} from "../drizzle/schema";

export interface EligibilityResult {
  eligible: boolean;
  reason: string;
  timeInRankDays: number | null;
}

/**
 * Promotion eligibility engine.
 *
 * Evaluates a promotion request against administrator-configured rules:
 *  1. The department must be active.
 *  2. The requested rank must be exactly the next rank in the configured
 *     hierarchy (skipping ranks is not allowed).
 *  3. Time-in-rank: days since the citizen joined the department (or since
 *     the last completed promotion, whichever is later) must reach the
 *     department's minimum configured days.
 *  4. No other open request for the same player in the same department.
 */
export async function evaluateEligibility(params: {
  department: Department;
  discordId: string;
  currentRank: string;
  requestedRank: string;
}): Promise<EligibilityResult> {
  const { department, discordId, currentRank, requestedRank } = params;

  if (!department.isActive) {
    return { eligible: false, reason: "القسم غير مُفعّل حالياً", timeInRankDays: null };
  }

  const ranks = department.ranks ?? [];
  const currentIndex = ranks.indexOf(currentRank);
  const requestedIndex = ranks.indexOf(requestedRank);

  if (currentIndex === -1) {
    return {
      eligible: false,
      reason: "الرتبة الحالية غير موجودة في هرم رتب القسم",
      timeInRankDays: null,
    };
  }
  if (requestedIndex === -1) {
    return {
      eligible: false,
      reason: "الرتبة المطلوبة غير موجودة في هرم رتب القسم",
      timeInRankDays: null,
    };
  }
  if (requestedIndex !== currentIndex + 1) {
    return {
      eligible: false,
      reason: "لا يمكن تخطي الرتب: الرتبة المطلوبة يجب أن تكون التالية مباشرة",
      timeInRankDays: null,
    };
  }

  const db = await getDb();
  if (!db) {
    return {
      eligible: false,
      reason: "قاعدة البيانات غير متاحة حالياً",
      timeInRankDays: null,
    };
  }

  // Time in rank: from the citizen's joining date, or from the last completed
  // promotion in the same department — whichever is later.
  const [citizen] = await db
    .select()
    .from(citizens)
    .where(eq(citizens.discordId, discordId))
    .limit(1);

  const [lastPromoted] = await db
    .select({ latest: max(promotionRequests.processedAt) })
    .from(promotionRequests)
    .where(
      and(
        eq(promotionRequests.discordId, discordId),
        eq(promotionRequests.departmentId, department.id),
        inArray(promotionRequests.status, ["approved", "completed"]),
      ),
    );

  const baseDate =
    lastPromoted?.latest && citizen?.joinedAt && lastPromoted.latest > citizen.joinedAt
      ? lastPromoted.latest
      : (citizen?.joinedAt ?? null);

  if (!baseDate) {
    return {
      eligible: false,
      reason: "لا يوجد سجل خدمة موثق لهذا اللاعب في المجتمع",
      timeInRankDays: null,
    };
  }

  const timeInRankDays = Math.floor(
    (Date.now() - new Date(baseDate).getTime()) / (1000 * 60 * 60 * 24),
  );

  if (timeInRankDays < department.minDaysInRank) {
    return {
      eligible: false,
      reason: `لم تكتمل مدة اللقب: المطلوب ${department.minDaysInRank} يوماً والمتبقي ${department.minDaysInRank - timeInRankDays} يوماً`,
      timeInRankDays,
    };
  }

  return {
    eligible: true,
    reason: "مؤهل: استُوفت مدة اللقب والرتبة المطلوبة هي التالية مباشرة في هرم القسم",
    timeInRankDays,
  };
}

/** Seeds default departments when the table is empty (first run). */
export async function ensureDefaultDepartments(): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const existing = await db.select({ id: departments.id }).from(departments).limit(1);
  if (existing.length > 0) return;

  await db.insert(departments).values([
    {
      key: "police",
      name: "قوة الشرطة",
      description: "إنفاذ القانون وحفظ الأمن في مدينة ويستوريا",
      type: "military",
      ranks: ["مخبر", "شرطي", "رقيب", "نقيب", "مقدم", "عقيد", "لواء"],
      minDaysInRank: 7,
      managerUserIds: [],
    },
    {
      key: "traffic",
      name: "إدارة المرور",
      description: "تنظيم حركة المرور والتحقيق في الحوادث",
      type: "military",
      ranks: ["مخبر", "شرطي مرور", "رقيب", "نقيب", "عقيد"],
      minDaysInRank: 5,
      managerUserIds: [],
    },
    {
      key: "civil-defense",
      name: "الدفاع المدني",
      description: "مكافحة الحرائق وعمليات الإنقاذ",
      type: "military",
      ranks: ["مخبر", "رجل إطفاء", "رقيب", "نقيب", "عقيد"],
      minDaysInRank: 5,
      managerUserIds: [],
    },
    {
      key: "medical",
      name: "الخدمات الطبية",
      description: "الإسعاف والطوارئ والمستشفيات",
      type: "military",
      ranks: ["مسعف متدرب", "مسعف", "فني طوارئ", "طبيب مقيم", "طبيب أول"],
      minDaysInRank: 5,
      managerUserIds: [],
    },
    {
      key: "government",
      name: "الديوان الحكومي",
      description: "القطاعات الحكومية والخدمات العامة",
      type: "government",
      ranks: ["موظف", "رئيس قسم", "مدير إدارة", "نائب أمين", "أمين"],
      minDaysInRank: 10,
      managerUserIds: [],
    },
    {
      key: "mechanics",
      name: "ورش الميكانيكا",
      description: "صيانة وإنقاذ المركبات",
      type: "civilian",
      ranks: ["متدرب", "ميكانيكي", "فني أول", "مالك ورشة"],
      minDaysInRank: 3,
      managerUserIds: [],
    },
    {
      key: "business",
      name: "الأعمال التجارية",
      description: "المتاجر والمطاعم والشركات الخاصة",
      type: "civilian",
      ranks: ["موظف", "مشرف", "مدير فرع", "صاحب عمل"],
      minDaysInRank: 3,
      managerUserIds: [],
    },
  ]);
}
