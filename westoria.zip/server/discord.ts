/**
 * Secure Discord integration layer (official Discord REST API v10).
 *
 * All credentials are read from environment variables (project secrets) and
 * never leave the server. The web app is the primary UI: players never type
 * slash commands; this layer performs authorized role assignments and member
 * notifications from the backend only.
 *
 * The integration reports itself honestly: until real credentials (bot token,
 * guild id, client id/secret) are configured and verified, every helper
 * returns { configured: false } and no Discord call is attempted.
 */

const DISCORD_API = "https://discord.com/api/v10";

export interface DiscordConfig {
  botToken: string | null;
  guildId: string | null;
  clientId: string | null;
  clientSecret: string | null;
}

export function getDiscordConfig(): DiscordConfig {
  return {
    botToken: process.env.DISCORD_BOT_TOKEN || null,
    guildId: process.env.DISCORD_GUILD_ID || null,
    clientId: process.env.DISCORD_CLIENT_ID || null,
    clientSecret: process.env.DISCORD_CLIENT_SECRET || null,
  };
}

/** OAuth2 login is ready only when both client credentials exist. */
export function isDiscordOAuthConfigured(): boolean {
  const cfg = getDiscordConfig();
  return Boolean(cfg.clientId && cfg.clientSecret);
}

/** Bot-backed role assignment is ready only when token + guild exist. */
export function isBotConfigured(): boolean {
  const cfg = getDiscordConfig();
  return Boolean(cfg.botToken && cfg.guildId);
}

export interface DiscordOperationResult {
  performed: boolean;
  success: boolean;
  detail: string;
}

/**
 * Adds a role to a guild member (and removes the previous rank role when
 * provided). Performed with the bot token from the backend.
 */
export async function assignRankRole(params: {
  discordId: string;
  roleId: string | null;
  previousRoleId?: string | null;
}): Promise<DiscordOperationResult> {
  if (!isBotConfigured()) {
    return {
      performed: false,
      success: false,
      detail: "تكامل Discord غير مُهيأ (توكن البوت/Guild ID غير مضبوطين) — لم تُنفذ أي عملية",
    };
  }
  const { botToken, guildId } = getDiscordConfig();
  if (!params.roleId) {
    return {
      performed: false,
      success: false,
      detail: "لا يوجد معرف رتبة Discord مُهيأ لهذا القسم",
    };
  }

  try {
    if (params.previousRoleId && params.previousRoleId !== params.roleId) {
      await discordFetch(
        `/guilds/${guildId}/members/${params.discordId}/roles/${params.previousRoleId}`,
        { method: "DELETE", botToken: botToken! },
      );
    }
    await discordFetch(
      `/guilds/${guildId}/members/${params.discordId}/roles/${params.roleId}`,
      { method: "PUT", botToken: botToken! },
    );
    return { performed: true, success: true, detail: "تم تعيين الرتبة على Discord" };
  } catch (error) {
    return {
      performed: true,
      success: false,
      detail: `فشل تعيين الرتبة على Discord: ${(error as Error).message}`,
    };
  }
}

/** Sends a direct message to a member through the bot. */
export async function notifyMember(params: {
  discordId: string;
  message: string;
}): Promise<DiscordOperationResult> {
  if (!isBotConfigured()) {
    return {
      performed: false,
      success: false,
      detail: "تكامل Discord غير مُهيأ — لم يُرسل أي إشعار",
    };
  }
  const { botToken } = getDiscordConfig();
  try {
    const dmChannel = (await discordFetch(`/users/@me/channels`, {
      method: "POST",
      botToken: botToken!,
      body: { recipient_id: params.discordId },
    })) as { id?: string };

    if (!dmChannel?.id) throw new Error("تعذر إنشاء قناة خاصة");

    await discordFetch(`/channels/${dmChannel.id}/messages`, {
      method: "POST",
      botToken: botToken!,
      body: { content: params.message },
    });
    return { performed: true, success: true, detail: "أُرسل الإشعار للعضو" };
  } catch (error) {
    return {
      performed: true,
      success: false,
      detail: `فشل إرسال الإشعار: ${(error as Error).message}`,
    };
  }
}

/** Exchanges an OAuth2 code for Discord user + guild member identity. */
export async function exchangeOAuthCode(params: {
  code: string;
  redirectUri: string;
}): Promise<{ user: Record<string, unknown>; accessToken: string } | null> {
  const { clientId, clientSecret } = getDiscordConfig();
  if (!clientId || !clientSecret) return null;

  const body = new URLSearchParams({
    client_id: clientId,
    client_secret: clientSecret,
    grant_type: "authorization_code",
    code: params.code,
    redirect_uri: params.redirectUri,
  });

  const tokenRes = await fetch(`${DISCORD_API}/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });
  if (!tokenRes.ok) {
    throw new Error(`Discord token exchange failed (${tokenRes.status})`);
  }
  const token = (await tokenRes.json()) as { access_token: string };

  const userRes = await fetch(`${DISCORD_API}/users/@me`, {
    headers: { Authorization: `Bearer ${token.access_token}` },
  });
  if (!userRes.ok) {
    throw new Error(`Discord user fetch failed (${userRes.status})`);
  }
  const user = (await userRes.json()) as Record<string, unknown>;
  return { user, accessToken: token.access_token };
}

/** Fetches a member's roles in the configured guild (requires OAuth token with guilds.members.read). */
export async function fetchGuildMemberRoles(params: {
  accessToken: string;
  discordUserId: string;
}): Promise<string[] | null> {
  const { guildId } = getDiscordConfig();
  if (!guildId) return null;
  try {
    const member = (await discordFetch(
      `/guilds/${guildId}/members/${params.discordUserId}`,
      { method: "GET", botToken: getDiscordConfig().botToken! },
    )) as { roles?: string[] };
    return member?.roles ?? null;
  } catch {
    return null;
  }
}

async function discordFetch(
  path: string,
  options: { method: string; botToken: string; body?: unknown },
): Promise<unknown> {
  const res = await fetch(`${DISCORD_API}${path}`, {
    method: options.method,
    headers: {
      Authorization: `Bot ${options.botToken}`,
      "Content-Type": "application/json",
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`${res.status} ${text.slice(0, 200)}`);
  }
  const contentType = res.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) return res.json();
  return null;
}
