import { getDb } from "./db";
import { auditLogs, type InsertAuditLog } from "../drizzle/schema";

/**
 * Records an immutable audit entry for every sensitive action.
 * Never throws into the caller path: a logging failure must not break the
 * business operation, but it is surfaced in server logs.
 */
export async function logAudit(entry: InsertAuditLog): Promise<void> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[Audit] Database not available, audit entry dropped");
      return;
    }
    await db.insert(auditLogs).values(entry);
  } catch (error) {
    console.error("[Audit] Failed to write audit log:", error);
  }
}
